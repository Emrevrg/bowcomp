/**
 * Ambient module declaration for the optional private gateway client package.
 *
 * This allows TypeScript to resolve `import('@bowcomp/llm-gateway-client')`
 * even when the package isn't installed (OSS builds). The real package
 * provides its own types when installed in Free builds.
 */
declare module '@bowcomp/llm-gateway-client' {
  import type { BowcompRuntime } from '@bowcomp/agent-core';
  export function createRuntime(): BowcompRuntime;
}
