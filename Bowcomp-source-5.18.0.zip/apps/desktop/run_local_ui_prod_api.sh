#!/bin/bash
# Run desktop app with LOCAL UI (Vite hot reload)
# UI: localhost:3000
BOWCOMP_ROUTER_URL=http://localhost:3000 pnpm dev
