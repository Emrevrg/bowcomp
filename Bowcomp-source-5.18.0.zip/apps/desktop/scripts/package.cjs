#!/usr/bin/env node

/**
 * Custom packaging script for Electron app with pnpm workspaces.
 *
 * Temporarily removes workspace symlinks that cause electron-builder
 * issues, and substitutes pnpm's `.pnpm/` store symlinks with real
 * copies for the opencode platform packages so electron-builder can
 * pack them. Restores both sets in a `finally` block so a failed build
 * leaves the working tree intact.
 *
 * Post-M6 (daemon-only-SQLite migration): Electron main ships no native
 * modules, so there's no `electron-rebuild` or `npmRebuild` toggling
 * here. The daemon keeps its own `better-sqlite3` built against the
 * bundled Node ABI via `scripts/stage-daemon-deps.cjs`.
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const isWindows = process.platform === 'win32';
const nodeModulesPath = path.join(__dirname, '..', 'node_modules');
const bowcompPath = path.join(nodeModulesPath, '@bowcomp');

// Save symlink targets for restoration
const workspacePackages = ['agent-core'];
const symlinkTargets = {};

// pnpm symlinks to resolve: these are regular dependencies that pnpm stores
// as symlinks to its content-addressable store, which electron-builder can't follow.
// We temporarily replace them with real copies of the resolved target.
const pnpmSymlinksToResolve = [
  'opencode-ai',
  'opencode-darwin-arm64',
  'opencode-darwin-x64',
  'opencode-darwin-x64-baseline',
  'opencode-linux-arm64',
  'opencode-linux-arm64-musl',
  'opencode-linux-x64',
  'opencode-linux-x64-baseline',
  'opencode-linux-x64-musl',
  'opencode-linux-x64-baseline-musl',
  'opencode-windows-x64-baseline',
];
const resolvedSymlinks = {};

try {
  // Check and remove workspace symlinks
  for (const pkg of workspacePackages) {
    const pkgPath = path.join(bowcompPath, pkg);
    if (fs.existsSync(pkgPath)) {
      const stats = fs.lstatSync(pkgPath);
      if (stats.isSymbolicLink()) {
        symlinkTargets[pkg] = fs.readlinkSync(pkgPath);
        console.log('Temporarily removing workspace symlink:', pkgPath);
        fs.unlinkSync(pkgPath);
      }
    }
  }

  // Remove empty @bowcomp directory if it exists
  if (Object.keys(symlinkTargets).length > 0) {
    try {
      fs.rmdirSync(bowcompPath);
    } catch {
      // Directory not empty or doesn't exist, ignore
    }
  }

  // Replace pnpm store symlinks with real copies so electron-builder can pack them
  for (const pkg of pnpmSymlinksToResolve) {
    const pkgPath = path.join(nodeModulesPath, pkg);
    if (fs.existsSync(pkgPath)) {
      const stats = fs.lstatSync(pkgPath);
      if (stats.isSymbolicLink()) {
        const linkTarget = fs.readlinkSync(pkgPath);
        const realPath = fs.realpathSync(pkgPath);
        resolvedSymlinks[pkg] = { linkTarget, pkgPath };
        console.log('Replacing pnpm symlink with copy:', pkgPath);
        fs.unlinkSync(pkgPath);
        fs.cpSync(realPath, pkgPath, { recursive: true });
      }
    }
  }

  // Get command line args (everything after 'node scripts/package.js')
  const args = process.argv.slice(2).join(' ');

  // Milestone 6 of the daemon-only-SQLite migration removed the
  // `--config.npmRebuild=false` Windows workaround: Electron main no
  // longer ships native modules (pre-M6 the flag existed to skip rebuild
  // of `better-sqlite3`, whose Windows prebuild is Electron-ABI-
  // compatible without rebuilding). `build.npmRebuild: false` in
  // package.json stays as a belt-and-braces guard.
  const command = `npx electron-builder ${args}`;

  console.log('Running:', command);
  execSync(command, { stdio: 'inherit', cwd: path.join(__dirname, '..') });
} finally {
  // Restore pnpm store symlinks
  for (const [pkg, { linkTarget, pkgPath }] of Object.entries(resolvedSymlinks)) {
    console.log('Restoring pnpm symlink:', pkgPath);
    if (fs.existsSync(pkgPath)) {
      fs.rmSync(pkgPath, { recursive: true, force: true });
    }
    if (isWindows) {
      const absoluteTarget = path.isAbsolute(linkTarget)
        ? linkTarget
        : path.resolve(path.dirname(pkgPath), linkTarget);
      fs.symlinkSync(absoluteTarget, pkgPath, 'junction');
    } else {
      fs.symlinkSync(linkTarget, pkgPath);
    }
  }

  // Restore the symlinks
  const packagesToRestore = Object.keys(symlinkTargets);
  if (packagesToRestore.length > 0) {
    console.log('Restoring workspace symlinks');

    // Recreate @bowcomp directory if needed
    if (!fs.existsSync(bowcompPath)) {
      fs.mkdirSync(bowcompPath, { recursive: true });
    }

    for (const pkg of packagesToRestore) {
      const pkgPath = path.join(bowcompPath, pkg);
      const target = symlinkTargets[pkg];

      // On Windows, use junction instead of symlink (doesn't require admin privileges)
      // The target needs to be an absolute path for junctions
      const absoluteTarget = path.isAbsolute(target)
        ? target
        : path.resolve(path.dirname(pkgPath), target);

      if (isWindows) {
        fs.symlinkSync(absoluteTarget, pkgPath, 'junction');
      } else {
        fs.symlinkSync(target, pkgPath);
      }
      console.log('  Restored:', pkgPath);
    }
  }
}
