import { app, BrowserWindow, Menu, Tray, nativeImage } from 'electron';
import path from 'path';
import fs from 'fs';
import { isAutoStartEnabled, enableAutoStart, disableAutoStart } from './daemon/service-manager';

let tray: Tray | null = null;
let trayWindow: BrowserWindow | null = null;
let activeTaskCount = 0;

function getTrayIcon(): Electron.NativeImage {
  const resourceRoot = app.isPackaged
    ? process.resourcesPath
    : path.join(process.env.APP_ROOT!, 'resources');
  const candidates =
    process.platform === 'win32'
      ? ['icon.ico', 'icon.png']
      : ['icon.png', 'icon.ico'];

  for (const fileName of candidates) {
    const iconPath = path.join(resourceRoot, fileName);
    if (!fs.existsSync(iconPath)) continue;
    const icon = nativeImage.createFromPath(iconPath);
    if (!icon.isEmpty()) return icon;
  }

  return nativeImage.createEmpty();
}

function buildContextMenu(mainWindow: BrowserWindow | null): Menu {
  const taskLabel = activeTaskCount > 0 ? `Active Tasks: ${activeTaskCount}` : 'No Active Tasks';

  const autoStartChecked = isAutoStartEnabled();

  return Menu.buildFromTemplate([
    {
      label: 'Show Bowcomp',
      click: () => {
        showWindow(mainWindow);
      },
    },
    { type: 'separator' },
    { label: taskLabel, enabled: false },
    { type: 'separator' },
    {
      label: 'Start at Login',
      type: 'checkbox',
      checked: autoStartChecked,
      click: (menuItem) => {
        if (menuItem.checked) {
          enableAutoStart();
        } else {
          disableAutoStart();
        }
      },
    },
    { type: 'separator' },
    {
      label: 'Quit',
      click: () => {
        app.quit();
      },
    },
  ]);
}

function showWindow(mainWindow: BrowserWindow | null): void {
  if (!mainWindow || mainWindow.isDestroyed()) {
    return;
  }
  if (mainWindow.isMinimized()) {
    mainWindow.restore();
  }
  mainWindow.show();
  mainWindow.focus();
}

export function createTray(mainWindow: BrowserWindow | null): Tray {
  trayWindow = mainWindow;
  const icon = getTrayIcon();

  // Resize for tray (16x16 on most platforms, 22x22 on Linux)
  const trayIcon =
    process.platform === 'linux'
      ? icon.resize({ width: 22, height: 22 })
      : icon.resize({ width: 16, height: 16 });

  tray = new Tray(trayIcon);
  tray.setToolTip('Bowcomp');
  tray.setContextMenu(buildContextMenu(mainWindow));

  tray.on('click', () => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      if (mainWindow.isVisible() && !mainWindow.isMinimized()) {
        mainWindow.hide();
      } else {
        showWindow(mainWindow);
      }
    }
  });

  return tray;
}

export function updateTaskCount(count: number, mainWindow: BrowserWindow | null): void {
  activeTaskCount = count;
  if (mainWindow && !mainWindow.isDestroyed()) {
    trayWindow = mainWindow;
  }
  if (tray && !tray.isDestroyed()) {
    tray.setContextMenu(buildContextMenu(mainWindow ?? trayWindow));
    const tooltip = count > 0 ? `Bowcomp - ${count} task(s) running` : 'Bowcomp';
    tray.setToolTip(tooltip);
  }
}

export function destroyTray(): void {
  if (tray && !tray.isDestroyed()) {
    tray.destroy();
    tray = null;
    trayWindow = null;
  }
}
/**
 * Update the tray icon/tooltip to reflect current task state.
 * Called when a task starts, completes, or fails.
 */
export function updateTray(): void {
  if (tray && !tray.isDestroyed()) {
    tray.setContextMenu(buildContextMenu(trayWindow));
  }
}
