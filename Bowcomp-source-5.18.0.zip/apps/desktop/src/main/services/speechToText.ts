/**
 * Speech-to-Text service wrapper for Electron desktop app.
 *
 * Delegates to the agent-core SpeechService but reads the ElevenLabs API key
 * through the shared secureStorage singleton so keys saved via settings are
 * visible here without a separate storage instance.
 *
 * Audio recording happens in the renderer process (uses browser APIs),
 * then audio data is sent to main process via IPC for transcription.
 *
 * Milestone 3 of the daemon-only-SQLite migration changed this module's
 * shape. Pre-M3 the module held a singleton `SpeechService` built with an
 * adapter that read from a local `SecureStorageAPI`. Post-M3 the key lives
 * in the daemon, and `getApiKey` is async. `SpeechService` expects a
 * synchronous `SecureStorageAPI.getApiKey(provider): string | null`, so
 * instead of caching we pre-fetch the key via RPC at the start of each
 * call and build a one-shot `SpeechService` around a frozen value. That
 * keeps the service API untouched in agent-core (no signature changes
 * rippling through the public surface) and sidesteps cache-staleness: if
 * the user rotates the key mid-session, the next speech invocation reads
 * the new value from the daemon.
 */

import { execFile } from 'node:child_process';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import { getApiKey } from '../store/secureStorage';
import {
  createSpeechService,
  type SpeechServiceAPI,
  type SecureStorageAPI,
  type TranscriptionResult,
  type TranscriptionError,
} from '@bowcomp/agent-core/desktop-main';

export type { TranscriptionResult, TranscriptionError } from '@bowcomp/agent-core/desktop-main';

export type SpeechProvider = 'local' | 'elevenlabs' | 'groq';

const GROQ_STT_MODEL_ID = 'whisper-large-v3-turbo';
const GROQ_TIMEOUT_MS = 30000;
const LOCAL_SPEECH_TIMEOUT_MS = 180000;
const execFileAsync = promisify(execFile);

/**
 * Build a one-shot `SpeechService` pre-seeded with the ElevenLabs API key
 * fetched from the daemon. Any `provider` other than `'elevenlabs'` returns
 * `null` — the service only ever asks for that one.
 */
async function buildServiceFromDaemon(): Promise<SpeechServiceAPI> {
  const elevenlabsKey = await getApiKey('elevenlabs');
  const fakeStorage = {
    getApiKey: (provider: string): string | null =>
      provider === 'elevenlabs' ? elevenlabsKey : null,
  } as unknown as SecureStorageAPI;
  return createSpeechService({ storage: fakeStorage });
}

/**
 * Build a `SpeechService` with a no-storage adapter. Every `getApiKey`
 * lookup returns `null`. Used when the caller supplies an explicit
 * `apiKey` override — the service's `validateElevenLabsApiKey(apiKey)`
 * never asks storage in that case, so making the RPC call would be
 * wasted work AND would fail in degraded startup / mock-daemon modes.
 */
function buildServiceWithoutStorage(): SpeechServiceAPI {
  const nullStorage = {
    getApiKey: (): string | null => null,
  } as unknown as SecureStorageAPI;
  return createSpeechService({ storage: nullStorage });
}

/**
 * Validate ElevenLabs API key by making a test request.
 *
 * The `apiKey` override path — used by the settings "test this key before
 * saving" flow — bypasses the daemon entirely: `SpeechService.validate`
 * uses the explicit param and never touches the adapter's `getApiKey`.
 * Pre-fetching would be both wasted work and a spurious failure in degraded
 * startup / `E2E_MOCK_TASK_EVENTS` paths.
 */
export async function validateElevenLabsApiKey(
  apiKey?: string,
): Promise<{ valid: boolean; error?: string }> {
  if (apiKey) {
    return buildServiceWithoutStorage().validateElevenLabsApiKey(apiKey);
  }
  const service = await buildServiceFromDaemon();
  return service.validateElevenLabsApiKey();
}

export async function validateGroqApiKey(
  apiKey?: string,
): Promise<{ valid: boolean; error?: string }> {
  const key = apiKey || (await getApiKey('groq'));
  if (!key || !key.trim()) {
    return { valid: false, error: 'API key is required' };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), GROQ_TIMEOUT_MS);
  try {
    const response = await fetch('https://api.groq.com/openai/v1/models', {
      method: 'GET',
      headers: { Authorization: `Bearer ${key.trim()}` },
      signal: controller.signal,
    });
    if (response.ok) {
      return { valid: true };
    }
    if (response.status === 401 || response.status === 403) {
      return { valid: false, error: 'Invalid Groq API key. Please check your settings.' };
    }
    const text = await response.text().catch(() => '');
    return {
      valid: false,
      error: `Groq API returned ${response.status}${text ? `: ${text.slice(0, 160)}` : ''}`,
    };
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      return { valid: false, error: 'Request timed out. Please check your internet connection.' };
    }
    const message = error instanceof Error ? error.message : 'Unknown error';
    return { valid: false, error: `Network error: ${message}` };
  } finally {
    clearTimeout(timer);
  }
}

async function parseGroqError(response: Response): Promise<string> {
  const text = await response.text().catch(() => '');
  if (!text) {
    return response.statusText || 'Unknown API error';
  }
  try {
    const parsed = JSON.parse(text) as { error?: { message?: string }; message?: string };
    return parsed.error?.message || parsed.message || text.slice(0, 200);
  } catch {
    return text.slice(0, 200);
  }
}

function escapePowerShellSingleQuoted(value: string): string {
  return value.replace(/'/g, "''");
}

async function getWindowsSpeechRecognizerCount(): Promise<number> {
  if (process.platform !== 'win32') {
    return 0;
  }

  try {
    const script =
      'Add-Type -AssemblyName System.Speech; ' +
      '[System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers().Count';
    const { stdout } = await execFileAsync(
      'powershell.exe',
      ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', script],
      { timeout: 10000, windowsHide: true },
    );
    const count = Number.parseInt(stdout.trim(), 10);
    return Number.isFinite(count) ? count : 0;
  } catch {
    return 0;
  }
}

let localSpeechAvailableCache: boolean | null = null;

export async function isLocalSpeechAvailable(): Promise<boolean> {
  if (localSpeechAvailableCache !== null) {
    return localSpeechAvailableCache;
  }
  localSpeechAvailableCache = (await getWindowsSpeechRecognizerCount()) > 0;
  return localSpeechAvailableCache;
}

async function transcribeWithWindowsSpeech(
  audioData: Buffer,
  mimeType: string,
): Promise<
  { success: true; result: TranscriptionResult } | { success: false; error: TranscriptionError }
> {
  const startTime = Date.now();
  if (process.platform !== 'win32') {
    return {
      success: false,
      error: {
        code: 'LOCAL_SPEECH_UNSUPPORTED',
        message: 'Local system speech recognition is currently available on Windows.',
      },
    };
  }
  if (!mimeType.toLowerCase().includes('wav')) {
    return {
      success: false,
      error: {
        code: 'LOCAL_SPEECH_FORMAT',
        message: 'Local system speech recognition requires WAV audio.',
      },
    };
  }
  if (!(await isLocalSpeechAvailable())) {
    return {
      success: false,
      error: {
        code: 'LOCAL_SPEECH_UNAVAILABLE',
        message: 'No Windows speech recognizer is installed for this system.',
      },
    };
  }

  const tempDir = await mkdtemp(path.join(tmpdir(), 'bowcomp-speech-'));
  const audioPath = path.join(tempDir, 'input.wav');
  await writeFile(audioPath, audioData);

  const escapedPath = escapePowerShellSingleQuoted(audioPath);
  const script = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$path = '${escapedPath}'
$installed = [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()
if (-not $installed -or $installed.Count -eq 0) { throw 'NO_RECOGNIZER' }
$cultureName = [System.Globalization.CultureInfo]::CurrentUICulture.Name
$recognizerInfo = $installed | Where-Object { $_.Culture.Name -eq $cultureName } | Select-Object -First 1
if (-not $recognizerInfo) { $recognizerInfo = $installed | Select-Object -First 1 }
$recognizer = New-Object System.Speech.Recognition.SpeechRecognitionEngine -ArgumentList $recognizerInfo
$grammar = New-Object System.Speech.Recognition.DictationGrammar
$recognizer.LoadGrammar($grammar)
$recognizer.SetInputToWaveFile($path)
$parts = New-Object System.Collections.Generic.List[string]
while ($true) {
  $result = $recognizer.Recognize([TimeSpan]::FromSeconds(15))
  if ($null -eq $result) { break }
  if ($result.Text) { $parts.Add($result.Text) }
}
$recognizer.Dispose()
[string]::Join(' ', $parts)
`;

  try {
    const { stdout, stderr } = await execFileAsync(
      'powershell.exe',
      ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', script],
      {
        timeout: LOCAL_SPEECH_TIMEOUT_MS,
        windowsHide: true,
        maxBuffer: 1024 * 1024,
      },
    );
    const text = stdout.trim();
    if (!text) {
      return {
        success: false,
        error: {
          code: 'EMPTY_RESULT',
          message:
            stderr.trim() || 'No speech was recognized. Try speaking closer to the microphone.',
        },
      };
    }
    return {
      success: true,
      result: {
        text,
        duration: Date.now() - startTime,
        timestamp: Date.now(),
      },
    };
  } catch (error) {
    const maybeExecError = error as Error & { killed?: boolean };
    if (maybeExecError.killed) {
      return {
        success: false,
        error: { code: 'TIMEOUT', message: 'Local speech recognition timed out.' },
      };
    }
    const message = error instanceof Error ? error.message : 'Unknown error';
    return {
      success: false,
      error: { code: 'LOCAL_SPEECH_FAILED', message },
    };
  } finally {
    await rm(tempDir, { recursive: true, force: true }).catch(() => {});
  }
}

async function callGroqTranscribe(
  apiKey: string,
  audioData: Buffer,
  mimeType: string,
): Promise<
  { success: true; result: TranscriptionResult } | { success: false; error: TranscriptionError }
> {
  const startTime = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), GROQ_TIMEOUT_MS);

  try {
    const blob = new Blob([new Uint8Array(audioData)], { type: mimeType });
    const formData = new FormData();
    formData.append('file', blob, 'audio.webm');
    formData.append('model', GROQ_STT_MODEL_ID);
    formData.append('response_format', 'json');

    const response = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}` },
      body: formData,
      signal: controller.signal,
    });

    if (!response.ok) {
      if (response.status === 401 || response.status === 403) {
        return {
          success: false,
          error: {
            code: 'INVALID_API_KEY',
            message: 'Invalid or expired Groq API key. Please check your voice settings.',
          },
        };
      }
      if (response.status === 429) {
        return {
          success: false,
          error: {
            code: 'RATE_LIMIT',
            message: 'Groq rate limit exceeded. Please wait a moment and try again.',
          },
        };
      }
      const message = await parseGroqError(response);
      return {
        success: false,
        error: { code: 'TRANSCRIPTION_FAILED', message: `Groq transcription failed: ${message}` },
      };
    }

    const result = (await response.json()) as { text?: string };
    if (!result.text?.trim()) {
      return {
        success: false,
        error: { code: 'EMPTY_RESULT', message: 'No speech was recognized. Please try again.' },
      };
    }

    return {
      success: true,
      result: {
        text: result.text.trim(),
        duration: Date.now() - startTime,
        timestamp: Date.now(),
      },
    };
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      return {
        success: false,
        error: { code: 'TIMEOUT', message: 'Transcription request timed out. Please try again.' },
      };
    }
    const message = error instanceof Error ? error.message : 'Unknown error';
    return {
      success: false,
      error: { code: 'NETWORK_ERROR', message: `Network error during transcription: ${message}` },
    };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Transcribe audio using ElevenLabs Speech-to-Text API
 *
 * @param audioData - Audio data as Buffer (from renderer via IPC)
 * @param mimeType - MIME type of the audio (e.g., 'audio/webm')
 * @returns Transcription result or error
 */
export async function transcribeAudio(
  audioData: Buffer,
  mimeType: string = 'audio/webm',
  provider: SpeechProvider = 'elevenlabs',
): Promise<
  { success: true; result: TranscriptionResult } | { success: false; error: TranscriptionError }
> {
  if (provider === 'local') {
    return transcribeWithWindowsSpeech(audioData, mimeType);
  }

  if (provider === 'groq') {
    const groqKey = await getApiKey('groq');
    if (!groqKey?.trim()) {
      return {
        success: false,
        error: {
          code: 'MISSING_API_KEY',
          message: 'Groq API key is not configured. Please add it in voice settings.',
        },
      };
    }
    return callGroqTranscribe(groqKey, audioData, mimeType);
  }

  const service = await buildServiceFromDaemon();
  return service.transcribeAudio(audioData, mimeType);
}
