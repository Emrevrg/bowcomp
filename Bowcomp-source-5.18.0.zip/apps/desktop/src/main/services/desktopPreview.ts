import { BrowserWindow, desktopCapturer } from 'electron';
import { getLogCollector } from '@main/logging';

const CAPTURE_INTERVAL_MS = 750;
const THUMBNAIL_SIZE = { width: 960, height: 540 };

interface DesktopPreviewSession {
  timer: NodeJS.Timeout;
  capturing: boolean;
}

const sessions = new Map<string, DesktopPreviewSession>();

function sendToRenderer(channel: string, payload: unknown): void {
  for (const win of BrowserWindow.getAllWindows()) {
    if (!win.isDestroyed()) {
      win.webContents.send(channel, payload);
    }
  }
}

function emitStatus(
  taskId: string,
  status: 'starting' | 'streaming' | 'stopped' | 'error',
  message?: string,
): void {
  sendToRenderer('desktop:status', { taskId, status, message, timestamp: Date.now() });
}

async function captureFrame(taskId: string): Promise<void> {
  const sources = await desktopCapturer.getSources({
    types: ['screen'],
    thumbnailSize: THUMBNAIL_SIZE,
  });
  const source = sources[0];
  if (!source || source.thumbnail.isEmpty()) {
    throw new Error('No desktop source available');
  }
  sendToRenderer('desktop:frame', {
    taskId,
    frame: source.thumbnail.toDataURL(),
    timestamp: Date.now(),
  });
}

export async function startDesktopPreviewStream(taskId: string): Promise<void> {
  await stopDesktopPreviewStream(taskId);
  emitStatus(taskId, 'starting');

  const session: DesktopPreviewSession = {
    capturing: false,
    timer: setInterval(() => {
      void tick(taskId);
    }, CAPTURE_INTERVAL_MS),
  };
  sessions.set(taskId, session);

  await tick(taskId);
}

async function tick(taskId: string): Promise<void> {
  const session = sessions.get(taskId);
  if (!session || session.capturing) {
    return;
  }
  session.capturing = true;
  try {
    await captureFrame(taskId);
    emitStatus(taskId, 'streaming');
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    emitStatus(taskId, 'error', 'Desktop preview is reconnecting...');
    getLogCollector().logBrowser('WARN', `[DesktopPreview] Capture failed: ${message}`);
  } finally {
    session.capturing = false;
  }
}

export async function stopDesktopPreviewStream(taskId: string): Promise<void> {
  const session = sessions.get(taskId);
  if (!session) {
    return;
  }
  clearInterval(session.timer);
  sessions.delete(taskId);
  emitStatus(taskId, 'stopped');
}

export async function stopAllDesktopPreviewStreams(): Promise<void> {
  const taskIds = Array.from(sessions.keys());
  await Promise.all(taskIds.map((taskId) => stopDesktopPreviewStream(taskId)));
}
