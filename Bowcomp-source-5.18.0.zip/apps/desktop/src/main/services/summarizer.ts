/**
 * @deprecated Import from '@bowcomp/agent-core/desktop-main' instead.
 * This file re-exports from the core package for backward compatibility.
 */

export { generateTaskSummary, type GetApiKeyFn } from '@bowcomp/agent-core/desktop-main';
