import type { IpcMainInvokeEvent } from 'electron';
import { getApiKey } from '../../store/secureStorage';
import {
  validateElevenLabsApiKey,
  validateGroqApiKey,
  isLocalSpeechAvailable,
  transcribeAudio,
  type SpeechProvider,
} from '../../services/speechToText';
import { getLogCollector } from '../../logging';
import { handle } from './utils';

const MAX_AUDIO_SIZE = 25 * 1024 * 1024; // 25 MB
const MAX_LOCAL_AUDIO_SIZE = 100 * 1024 * 1024; // 100 MB for local WAV long-form capture
type CloudSpeechProvider = Exclude<SpeechProvider, 'local'>;
const CLOUD_SPEECH_PROVIDERS: CloudSpeechProvider[] = ['elevenlabs', 'groq'];

function normalizeSpeechProvider(provider?: string): SpeechProvider {
  if (provider === 'local' || provider === 'groq') {
    return provider;
  }
  return 'elevenlabs';
}

export function registerSpeechHandlers(): void {
  handle('speech:is-configured', async (_event: IpcMainInvokeEvent, provider?: string) => {
    const selectedProvider = normalizeSpeechProvider(provider);
    if (selectedProvider === 'local') {
      return isLocalSpeechAvailable();
    }
    const apiKey = await getApiKey(selectedProvider);
    return Boolean(apiKey && apiKey.trim());
  });

  handle('speech:get-config', async (_event: IpcMainInvokeEvent) => {
    const localAvailable = await isLocalSpeechAvailable();
    const providers = await Promise.all(
      CLOUD_SPEECH_PROVIDERS.map(async (provider) => {
        const apiKey = await getApiKey(provider);
        return [
          provider,
          {
            enabled: Boolean(apiKey && apiKey.trim()),
            hasApiKey: Boolean(apiKey),
            apiKeyPrefix: apiKey ? `${apiKey.substring(0, 8)}...` : undefined,
          },
        ] as const;
      }),
    );
    const cloudProviderConfig = Object.fromEntries(providers) as Record<
      CloudSpeechProvider,
      { enabled: boolean; hasApiKey: boolean; apiKeyPrefix?: string }
    >;
    const providerConfig = {
      local: {
        enabled: localAvailable,
        hasApiKey: localAvailable,
      },
      ...cloudProviderConfig,
    };
    const apiKey = providerConfig.elevenlabs?.hasApiKey ? await getApiKey('elevenlabs') : null;
    return {
      enabled: localAvailable || Boolean(apiKey && apiKey.trim()),
      hasApiKey: localAvailable || Boolean(apiKey),
      apiKeyPrefix: apiKey ? apiKey.substring(0, 8) + '...' : undefined,
      providers: providerConfig,
    };
  });

  handle(
    'speech:validate',
    async (_event: IpcMainInvokeEvent, providerOrApiKey?: string, maybeApiKey?: string) => {
      if (providerOrApiKey === 'local') {
        const valid = await isLocalSpeechAvailable();
        return {
          valid,
          ...(valid ? {} : { error: 'Windows speech recognition is not installed.' }),
        };
      }
      const hasProviderArg = CLOUD_SPEECH_PROVIDERS.includes(
        providerOrApiKey as CloudSpeechProvider,
      );
      const provider = hasProviderArg ? (providerOrApiKey as CloudSpeechProvider) : 'elevenlabs';
      const apiKey = hasProviderArg ? maybeApiKey : providerOrApiKey;
      return provider === 'groq' ? validateGroqApiKey(apiKey) : validateElevenLabsApiKey(apiKey);
    },
  );

  handle(
    'speech:transcribe',
    async (
      _event: IpcMainInvokeEvent,
      audioData: ArrayBuffer,
      mimeType?: string,
      provider?: string,
    ) => {
      const logger = getLogCollector();
      const selectedProvider = normalizeSpeechProvider(provider);
      logger.logEnv('INFO', '[IPC] speech:transcribe received', {
        audioDataType: typeof audioData,
        audioDataByteLength: audioData?.byteLength,
        mimeType,
        provider: selectedProvider,
      });
      const maxAudioSize = selectedProvider === 'local' ? MAX_LOCAL_AUDIO_SIZE : MAX_AUDIO_SIZE;
      if (audioData?.byteLength > maxAudioSize) {
        throw new Error(
          `Audio payload exceeds maximum allowed size of ${maxAudioSize / 1024 / 1024} MB`,
        );
      }
      const buffer = Buffer.from(audioData);
      logger.logEnv('INFO', '[IPC] Converted to buffer', { bufferLength: buffer.length });
      return transcribeAudio(buffer, mimeType, selectedProvider);
    },
  );
}
