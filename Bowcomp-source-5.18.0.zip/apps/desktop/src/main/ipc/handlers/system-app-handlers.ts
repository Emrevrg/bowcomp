import { BrowserWindow } from 'electron';
import type { IpcMainInvokeEvent } from 'electron';
import { execFile } from 'child_process';
import { handle, assertTrustedWindow } from './utils';

export interface SystemAppInfo {
  id: string;
  name: string;
  path?: string;
  arguments?: string;
  appId?: string;
  source: 'start-menu' | 'appx' | 'registry';
}

const LIST_APPS_SCRIPT = `
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
$seen = @{}
$items = New-Object System.Collections.Generic.List[object]
function Add-BowcompApp($Name, $Path, $Arguments, $AppId, $Source) {
  if ([string]::IsNullOrWhiteSpace($Name)) { return }
  $key = (($Name + '|' + $Path + '|' + $AppId).ToLowerInvariant())
  if ($seen.ContainsKey($key)) { return }
  $seen[$key] = $true
  $items.Add([pscustomobject]@{
    id = $key
    name = $Name
    path = $Path
    arguments = $Arguments
    appId = $AppId
    source = $Source
  }) | Out-Null
}

$roots = @(
  [System.IO.Path]::Combine($env:APPDATA, 'Microsoft\\Windows\\Start Menu\\Programs'),
  [System.IO.Path]::Combine($env:ProgramData, 'Microsoft\\Windows\\Start Menu\\Programs')
)

try {
  $wsh = New-Object -ComObject WScript.Shell
  foreach ($root in $roots) {
    if (-not (Test-Path -LiteralPath $root)) { continue }
    Get-ChildItem -LiteralPath $root -Filter '*.lnk' -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
      try {
        $shortcut = $wsh.CreateShortcut($_.FullName)
        $target = $shortcut.TargetPath
        if (-not [string]::IsNullOrWhiteSpace($target)) {
          Add-BowcompApp ([System.IO.Path]::GetFileNameWithoutExtension($_.Name)) $target $shortcut.Arguments $null 'start-menu'
        }
      } catch {}
    }
  }
} catch {}

try {
  Get-StartApps | ForEach-Object {
    Add-BowcompApp $_.Name $null $null $_.AppID 'appx'
  }
} catch {}

try {
  $registryRoots = @(
    'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*',
    'HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*',
    'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*'
  )
  foreach ($root in $registryRoots) {
    Get-ItemProperty $root -ErrorAction SilentlyContinue | ForEach-Object {
      if ($_.DisplayName) {
        $icon = $_.DisplayIcon
        if ($icon -and $icon.Contains(',')) { $icon = $icon.Split(',')[0] }
        Add-BowcompApp $_.DisplayName $icon $null $null 'registry'
      }
    }
  }
} catch {}

$items | Sort-Object name | Select-Object -First 500 | ConvertTo-Json -Depth 4
`;

function runPowerShell(script: string): Promise<string> {
  return new Promise((resolve, reject) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
      { windowsHide: true, timeout: 10000, maxBuffer: 1024 * 1024 * 4, encoding: 'utf8' },
      (error, stdout, stderr) => {
        if (error) {
          reject(new Error(stderr || error.message));
          return;
        }
        resolve(stdout);
      },
    );
  });
}

function normalizeAppRows(stdout: string): SystemAppInfo[] {
  const trimmed = stdout.trim();
  if (!trimmed) return [];
  const raw = JSON.parse(trimmed) as SystemAppInfo | SystemAppInfo[];
  const rows = Array.isArray(raw) ? raw : [raw];
  return rows
    .filter((row) => row?.name && typeof row.name === 'string')
    .map((row, index) => ({
      id: row.id || `${row.name}-${row.path || row.appId || index}`,
      name: row.name,
      path: row.path || undefined,
      arguments: row.arguments || undefined,
      appId: row.appId || undefined,
      source: row.source || 'start-menu',
    }));
}

function filterApps(apps: SystemAppInfo[], query?: string): SystemAppInfo[] {
  const q = query?.trim().toLowerCase();
  const filtered = q
    ? apps.filter(
        (app) =>
          app.name.toLowerCase().includes(q) ||
          app.path?.toLowerCase().includes(q) ||
          app.appId?.toLowerCase().includes(q),
      )
    : apps;
  return filtered.slice(0, 80);
}

export function registerSystemAppHandlers(): void {
  handle('system-apps:list', async (event: IpcMainInvokeEvent, query?: string) => {
    assertTrustedWindow(BrowserWindow.fromWebContents(event.sender));
    const apps = normalizeAppRows(await runPowerShell(LIST_APPS_SCRIPT));
    return filterApps(apps, typeof query === 'string' ? query : undefined);
  });
}
