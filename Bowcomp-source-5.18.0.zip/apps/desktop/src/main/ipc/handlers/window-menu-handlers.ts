import { app, BrowserWindow, dialog } from 'electron';
import { handle, assertTrustedWindow } from './utils';

type WindowMenuAction =
  | 'file:new-task'
  | 'file:settings'
  | 'file:close'
  | 'file:quit'
  | 'edit:undo'
  | 'edit:redo'
  | 'edit:cut'
  | 'edit:copy'
  | 'edit:paste'
  | 'edit:select-all'
  | 'view:reload'
  | 'view:force-reload'
  | 'view:toggle-devtools'
  | 'view:zoom-in'
  | 'view:zoom-out'
  | 'view:reset-zoom'
  | 'view:toggle-fullscreen'
  | 'window:minimize'
  | 'window:maximize'
  | 'window:close'
  | 'help:about';

function clampZoomFactor(value: number): number {
  return Math.max(0.5, Math.min(3, value));
}

export function registerWindowMenuHandlers(): void {
  handle<[WindowMenuAction], void>('app:window-menu-action', async (event, action) => {
    const window = assertTrustedWindow(BrowserWindow.fromWebContents(event.sender));
    const webContents = window.webContents;

    switch (action) {
      case 'file:new-task':
        webContents.send('app:navigate-home');
        return;
      case 'file:settings':
        webContents.send('app:open-settings');
        return;
      case 'file:close':
      case 'window:close':
        window.close();
        return;
      case 'file:quit':
        app.quit();
        return;
      case 'edit:undo':
        webContents.undo();
        return;
      case 'edit:redo':
        webContents.redo();
        return;
      case 'edit:cut':
        webContents.cut();
        return;
      case 'edit:copy':
        webContents.copy();
        return;
      case 'edit:paste':
        webContents.paste();
        return;
      case 'edit:select-all':
        webContents.selectAll();
        return;
      case 'view:reload':
        webContents.reload();
        return;
      case 'view:force-reload':
        webContents.reloadIgnoringCache();
        return;
      case 'view:toggle-devtools':
        webContents.toggleDevTools();
        return;
      case 'view:zoom-in':
        webContents.setZoomFactor(clampZoomFactor(webContents.getZoomFactor() + 0.1));
        return;
      case 'view:zoom-out':
        webContents.setZoomFactor(clampZoomFactor(webContents.getZoomFactor() - 0.1));
        return;
      case 'view:reset-zoom':
        webContents.setZoomFactor(1);
        return;
      case 'view:toggle-fullscreen':
        window.setFullScreen(!window.isFullScreen());
        return;
      case 'window:minimize':
        window.minimize();
        return;
      case 'window:maximize':
        if (window.isMaximized()) {
          window.unmaximize();
        } else {
          window.maximize();
        }
        return;
      case 'help:about':
        await dialog.showMessageBox(window, {
          type: 'info',
          title: 'About Bowcomp',
          message: 'Bowcomp',
          detail: `Version ${app.getVersion()}\n\nA desktop automation assistant.`,
          buttons: ['OK'],
        });
        return;
      default: {
        const exhaustive: never = action;
        throw new Error(`Unknown window menu action: ${exhaustive}`);
      }
    }
  });
}
