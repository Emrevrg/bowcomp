// Re-exported from core for better cross-platform support (Windows path delimiters)
export { getExtendedNodePath, findCommandInPath } from '@bowcomp/agent-core/desktop-main';
