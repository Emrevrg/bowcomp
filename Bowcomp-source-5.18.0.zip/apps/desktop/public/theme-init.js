(() => {
  // ../web/src/client/lib/theme-core.ts
  var THEME_KEY = "theme";
  function resolveTheme(preference) {
    if (preference === "system") {
      return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }
    return preference;
  }
  function applyClass(resolved) {
    if (resolved === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }
  function initEarlyTheme() {
    let stored = "system";
    try {
      stored = localStorage.getItem(THEME_KEY) || "system";
    } catch (_e) {
    }
    const preference = ["system", "light", "dark"].includes(stored) ? stored : "system";
    applyClass(resolveTheme(preference));
  }

  // <stdin>
  initEarlyTheme();
})();
