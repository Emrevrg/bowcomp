import fs from 'fs';
import path from 'path';
import { describe, expect, it } from 'vitest';

const HANDLERS_DIR = path.resolve(process.cwd(), 'src/main/ipc/handlers');
const HANDLE_CALL_RE = /handle(?:\w+)?\(\s*['"]([^'"]+)['"]/g;

function listTypeScriptFiles(dir: string): string[] {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      return listTypeScriptFiles(fullPath);
    }
    return entry.isFile() && entry.name.endsWith('.ts') ? [fullPath] : [];
  });
}

describe('IPC handler registration', () => {
  it('does not register duplicate channels', () => {
    const seen = new Map<string, string>();
    const duplicates: string[] = [];

    for (const file of listTypeScriptFiles(HANDLERS_DIR)) {
      const source = fs.readFileSync(file, 'utf8');
      HANDLE_CALL_RE.lastIndex = 0;
      for (let match = HANDLE_CALL_RE.exec(source); match; match = HANDLE_CALL_RE.exec(source)) {
        const channel = match[1];
        const location = path.relative(process.cwd(), file);
        const previous = seen.get(channel);
        if (previous) {
          duplicates.push(`${channel}: ${previous} and ${location}`);
        } else {
          seen.set(channel, location);
        }
      }
    }

    expect(duplicates).toEqual([]);
  });
});
