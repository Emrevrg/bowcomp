#!/bin/bash
# Build and run the unpacked Bowcomp app with its bundled UI.

set -e

echo "Building unpacked Bowcomp app..."
pnpm -F @bowcomp/desktop build:unpack

echo "Launching Bowcomp..."
open apps/desktop/release/mac-arm64/Bowcomp.app
