---
name: bowcomp-voice-providers
description: Use when helping configure or troubleshoot Bowcomp long voice conversation, the voice shortcut, OpenRouter API keys, Gemini API keys, or provider selection.
command: /voice-providers
---

# Bowcomp Voice And Provider Setup

Use this skill when a user wants help with Bowcomp voice input, long-form voice conversation, OpenRouter, Gemini, or voice shortcuts.

## Voice Input

- Open Settings > Voice Input.
- Prefer local Voicecomp / Windows speech output for free voice playback.
- Prefer Groq Whisper for the no-cost speech-to-text setup when Browser/Windows recognition is unavailable.
- Save a Groq API key for the free-tier cloud speech path, or an ElevenLabs key if the user explicitly chooses ElevenLabs.
- Use the microphone button for short dictation.
- Use the phone button next to chat for long-form voice conversation.
- Use `Ctrl+Shift+Space` to start or stop long-form voice conversation while the Bowcomp window is focused.
- For agent speech output, use the Voicecomp MCP tools: list voices first when needed, then speak text or save a WAV file locally.

## OpenRouter

- Open Settings > Providers.
- Select OpenRouter.
- Save the OpenRouter API key.
- Refresh or select a model before starting a task.

## Gemini

- Open Settings > Providers.
- Select Gemini.
- Save the Gemini API key.
- Refresh or select a Gemini model before starting a task.

## Troubleshooting

- If speech controls are disabled, confirm Groq or ElevenLabs is selected, the matching key is saved, and microphone permission is allowed in Windows.
- If Browser/Windows recognition reports `network`, switch to Groq Whisper; Chromium Web Speech is not reliable inside the Windows desktop shell.
- If a provider cannot run tasks, confirm the API key is saved, a model is selected, and the selected provider is the active provider.
- Do not expose API keys in chat, logs, screenshots, or skill files.
