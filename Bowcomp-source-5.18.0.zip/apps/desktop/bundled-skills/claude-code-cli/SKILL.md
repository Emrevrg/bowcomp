---
name: claude-code-cli
description: Use Anthropic's Claude Code CLI from inside Bowcomp when the user wants Claude (not Bowcomp's primary agent) to perform a coding task. Bowcomp prepares the prompt and surfaces the result.
---

# Claude Code (`/claude-code`)

Claude Code is Anthropic's official terminal agent (`claude` command), installed via `npm install -g @anthropic-ai/claude-code`. It runs in the user's terminal with persistent project memory in `CLAUDE.md`. Bowcomp does NOT impersonate Claude Code; this skill is purely a hand-off pattern.

## When to use

- User says "Claude Code'a ver", "use Claude Code", "open this in Claude".
- Long coding session that benefits from Claude's tool-use depth and `CLAUDE.md` memory.
- Multi-file refactor where Claude Code's permission model (`/permissions`) matches the user's preference.

## Workflow

1. Verify install:
   ```powershell
   claude --version
   ```
   Missing → tell the user `npm install -g @anthropic-ai/claude-code` and stop.

2. Compose a precise prompt. Claude Code is most reliable when given:
   - The repo root path
   - A bounded goal ("Migrate /api/users.ts to the new schema, run tests")
   - The success criterion ("`pnpm test` passes")

3. Launch:
   ```powershell
   claude --cwd "C:\path\to\repo" -p "Your task here"
   ```
   For autonomous runs the user's settings file controls permissions; do not override with `--dangerously-skip-permissions` unless the user explicitly asks.

4. Wait for `claude` to exit, then audit: `git status`, `git diff --stat`, run tests if appropriate.

5. Report what changed and whether the goal was met. If Claude Code asked a permission question and you ran in non-interactive mode, that is the failure mode — report it and ask the user.

## Boundaries

- Bowcomp's own agent is the default; only invoke Claude Code on explicit request.
- Never copy the user's Anthropic API key into the command line — Claude Code reads it from its own settings.
- The repo's `CLAUDE.md` is Claude Code's memory; don't overwrite it without consent.
