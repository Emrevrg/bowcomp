---
name: codex-cli
description: Use OpenAI Codex CLI from inside Bowcomp for long-running coding sessions. Codex runs as a separate persistent agent in the user's terminal. Bowcomp's role is to prepare the prompt, hand it off, and surface the result.
---

# Codex CLI (`/codex`)

OpenAI Codex CLI is a separate command-line agent installed via `npm install -g @openai/codex`. It runs persistent coding sessions with its own model (defaults to GPT-5/Codex). Bowcomp itself does NOT execute code in Codex; this skill teaches Bowcomp to **hand a task to Codex** and bring the result back.

## When to use

- The user explicitly says "Codex'e ver", "let Codex do this", "use codex".
- The task is a long, code-heavy refactor or autonomous bug-fix that benefits from Codex's persistent memory.
- The user is already inside a project they have on disk and wants Codex to work in-place.

Do **not** use this for short questions, browser tasks, or anything outside a code repository.

## Workflow

1. Confirm Codex is installed:
   ```powershell
   codex --version
   ```
   If not installed, instruct the user once: `npm install -g @openai/codex` and stop. Do not try to install it yourself.

2. Build a clear, single-paragraph prompt for Codex (no Bowcomp-internal vocabulary). Include: the goal, the directory, and the success check.

3. Hand off via `bash`:
   ```powershell
   codex --cwd "C:\path\to\repo" "Refactor the auth module to use the new SecureStorage API. Run the test suite. Stop when all tests pass."
   ```
   For non-interactive runs add `--auto-edit` and `--full-auto` only if the user has already authorized them globally.

4. After Codex exits, summarize: which files changed (`git status`), whether tests passed, whether the goal was met. Surface diff highlights with `git diff --stat`.

5. If Codex hits a blocker it cannot resolve, stop and report. Do not silently retry.

## Boundaries

- Bowcomp must not pretend to be Codex. If the user says "use Codex" and Codex is missing, say so.
- Never paste the user's API key into a Codex command — Codex reads its own auth from `~/.codex/auth.json`.
- Codex sessions persist; assume previous Codex state may exist in the project's `.codex/` folder.
