---
name: notebooklm
description: Help the user research, summarize, and synthesize a corpus of documents using Google NotebookLM. NotebookLM is a web app at notebooklm.google.com — Bowcomp opens the right tab, helps with source upload, and pulls findings back into local files.
---

# NotebookLM (`/notebooklm`)

NotebookLM is Google's source-grounded research tool. It accepts up to 50 PDFs / Google Docs / web URLs / pasted text per notebook and lets the user ask grounded questions, generate briefing docs, and produce audio overviews. Bowcomp does NOT have a NotebookLM API; this skill drives the web UI through `dev-browser`.

## When to use

- User says "NotebookLM'e at", "use notebooklm", "summarize these PDFs in NotebookLM".
- User has a corpus (PDFs, links, docs) and wants source-grounded answers, not free-form generation.
- Long research where the user wants citations back to original sources.

## Workflow

1. Open NotebookLM:
   ```javascript
   browser_navigate({ url: 'https://notebooklm.google.com/' })
   ```
   If the user is not signed in, stop and ask them to sign in once. Do not try to automate Google sign-in.

2. Create or open a notebook:
   - "Yeni notebook" / "+ New" button → name it after the task.
   - Or open an existing notebook by name from the sidebar.

3. Add sources. Use the **+ Add source** button. NotebookLM accepts:
   - PDF upload (drag-drop the local file path)
   - Google Drive picker
   - Website URL
   - Pasted text
   - YouTube URL
   For local PDFs, use `desktop_open_path` first to confirm the file exists, then upload.

4. Ask the user's question in the chat. NotebookLM grounds answers in the uploaded sources and shows citation chips.

5. To save findings back to the local machine, copy the response and use `desktop_create_document_file` (markdown) or `desktop_create_pdf_file` to persist it. Always preserve the source citations.

6. For long-form output the user can click "Briefing doc" / "Study guide" / "Audio Overview" inside NotebookLM. Surface the link or download path back to the user.

## Boundaries

- NotebookLM has hard caps: ~50 sources per notebook, ~500K words per source. If the user exceeds these, split into multiple notebooks.
- Do not paste secrets (API keys, passwords) into NotebookLM — it stores sources on Google's servers.
- NotebookLM is read-only on sources; it cannot edit external systems.
- If NotebookLM is rate-limited or unavailable, fall back to local document tools (`desktop_create_document_file`) using Bowcomp's primary model and tell the user citations will not be source-grounded.
