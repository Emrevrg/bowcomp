---
name: archive-to-pdf
description: 'Turn legally accessible browser-readable archive/book pages into a clean PDF without lowering page quality. Does not bypass DRM, paywalls, borrowing limits, or access controls.'
command: /archive-to-pdf
verified: true
---

# Skill: Archive to PDF

## Trigger

Use this skill when the user asks to save a readable online book, archive item, scan set, or page-by-page document as a PDF.

Typical requests:

- "Internet Archive'deki bu kitabi PDF yap"
- "Bu sayfalar sadece okunuyor, hepsini tek PDF'e cevir"
- "Kaliteyi bozmadan sayfalari PDF olarak kaydet"

## Safety and legality

Proceed only when the content is public domain, openly licensed, owned by the user, or the user confirms they have permission to make a personal copy.

Stop and explain the limitation if the site uses DRM, a paywall, a borrowing restriction, CAPTCHA, or a technical access control. Do not bypass, automate around, or remove those protections. Do not redistribute the resulting PDF.

## Inputs

- `url`: Browser page for the readable item.
- `output_name`: Desired PDF filename.
- `page_range`: Optional page range. If omitted, process all visible/readable pages.
- `quality`: Default `original`; do not downscale unless the user asks for a smaller file.

## Workflow

1. Open the URL in the browser and identify whether the item has an official PDF/download option.
2. If an official download exists and is allowed, use the `download-file` skill first.
3. If the item is only readable page-by-page, confirm that the user is allowed to make a personal PDF copy.
4. Detect the viewer page count and current zoom. Set zoom to the highest stable readable quality that keeps each page fully visible.
5. Capture pages one at a time as image files using the browser-visible rendered page, preserving original resolution where possible.
6. Validate that each captured page is nonblank, correctly oriented, and not duplicated.
7. Assemble the captures into a single PDF in page order.
8. Save the PDF under the user's Downloads folder unless they gave a specific folder.
9. Report the final path, page count, and any skipped pages.

## Quality checks

- Page text must be readable at the same or better quality as the browser viewer.
- Do not crop page edges.
- Do not include viewer controls, sidebars, overlays, or scrollbars.
- If a page fails to load, retry after a short wait before skipping.
- If the site rate-limits or blocks access, stop and report the exact blocker.

## Output

Return:

- PDF path
- Page count
- Source URL
- Any limitations encountered

