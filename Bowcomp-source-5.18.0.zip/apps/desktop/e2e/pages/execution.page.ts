import type { Page } from '@playwright/test';
import { TEST_TIMEOUTS } from '../config';

export class ExecutionPage {
  constructor(private page: Page) {}

  get statusBadge() {
    return this.page.getByTestId('execution-status-badge');
  }

  get cancelButton() {
    return this.page.getByTestId('execution-cancel-button');
  }

  get thinkingIndicator() {
    return this.page.getByTestId('execution-thinking-indicator');
  }

  get followUpInput() {
    return this.page.getByTestId('execution-follow-up-input');
  }

  get stopButton() {
    return this.page.getByTestId('execution-stop-button');
  }

  get permissionCard() {
    return this.page.getByTestId('execution-permission-card');
  }

  get allowButton() {
    return this.page.getByTestId('permission-allow-button');
  }

  get denyButton() {
    return this.page.getByTestId('permission-deny-button');
  }

  /** Get all question option buttons inside the permission card */
  get questionOptions() {
    return this.permissionCard.locator('button').filter({ hasText: /Option|Other/ });
  }

  /** Get the custom response textarea (always visible below options) */
  get customResponseInput() {
    return this.page.getByPlaceholder('Enter a different option...');
  }

  /** Get the messages scroll container */
  get messagesScrollContainer() {
    return this.page.getByTestId('messages-scroll-container');
  }

  /** Get the scroll-to-bottom button (visible when scrolled up) */
  get scrollToBottomButton() {
    return this.page.getByTestId('scroll-to-bottom-button');
  }

  /** Get all copy buttons on the page */
  get copyButtons() {
    return this.page.getByTestId('message-copy-button');
  }

  /** Get all code block copy buttons (syntax highlighter) */
  get codeBlockCopyButtons() {
    return this.page.getByTestId('code-block-copy-button');
  }

  get favoriteToggle() {
    return this.page.getByTestId('favorite-toggle');
  }

  get startNewTaskButton() {
    return this.page.getByTestId('start-new-task');
  }

  /** Select a question option by index (0-based) */
  async selectQuestionOption(index: number) {
    await this.questionOptions.nth(index).click();
  }

  async waitForComplete(timeout: number = TEST_TIMEOUTS.TASK_COMPLETE_WAIT) {
    await this.page.waitForFunction(
      () => {
        const badge = document.querySelector('[data-testid="execution-status-badge"]');
        if (!badge) return false;
        const text = badge.textContent?.toLowerCase() || '';
        return (
          text.includes('completed') ||
          text.includes('failed') ||
          text.includes('stopped') ||
          text.includes('cancelled')
        );
      },
      null,
      { timeout },
    );
  }
}
