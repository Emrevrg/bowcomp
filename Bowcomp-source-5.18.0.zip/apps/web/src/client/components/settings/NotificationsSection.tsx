import { useTranslation } from 'react-i18next';

interface NotificationsSectionProps {
  enabled: boolean;
  onToggle: () => void;
}

export function NotificationsSection({ enabled, onToggle }: NotificationsSectionProps) {
  const { t } = useTranslation('settings');

  return (
    <div className="rounded-md border border-border bg-card p-4">
      <div className="flex items-center justify-between gap-4">
        <div className="min-w-0 flex-1">
          <div className="font-medium text-foreground">{t('notifications.toggle.label')}</div>
          <p className="mt-1 text-sm text-muted-foreground leading-relaxed">
            {t('notifications.toggle.description')}
          </p>
        </div>
        <div className="shrink-0">
          <button
            role="switch"
            aria-checked={enabled}
            data-testid="settings-notifications-toggle"
            onClick={onToggle}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 ease-bowcomp ${
              enabled ? 'bg-primary' : 'bg-muted'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform duration-200 ease-bowcomp ${
                enabled ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
}
