import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { ResearchMode, TaskExecutionMode } from '@bowcomp/agent-core';
import { NotificationsSection } from '@/components/settings/NotificationsSection';
import { DebugSection } from '@/components/settings/DebugSection';
import { DaemonSection } from '@/components/settings/DaemonSection';
import { ThemeSelector } from '@/components/settings/ThemeSelector';
import { LanguageSelector } from '@/components/settings/LanguageSelector';
import { getBowcomp } from '@/lib/bowcomp';

interface GeneralTabProps {
  notificationsEnabled: boolean;
  onNotificationsToggle: () => void;
  debugMode: boolean;
  onDebugToggle: () => void;
}

const TASK_EXECUTION_MODES: Array<{ value: TaskExecutionMode; labelKey: string }> = [
  { value: 'auto', labelKey: 'taskBehavior.execution.auto' },
  { value: 'short', labelKey: 'taskBehavior.execution.short' },
  { value: 'balanced', labelKey: 'taskBehavior.execution.balanced' },
  { value: 'long', labelKey: 'taskBehavior.execution.long' },
  { value: 'unlimited', labelKey: 'taskBehavior.execution.unlimited' },
];

const RESEARCH_MODES: Array<{ value: ResearchMode; labelKey: string }> = [
  { value: 'standard', labelKey: 'taskBehavior.research.standard' },
  { value: 'deep', labelKey: 'taskBehavior.research.deep' },
  { value: 'multi_deep', labelKey: 'taskBehavior.research.multiDeep' },
];

function TaskBehaviorSection() {
  const { t } = useTranslation('settings');
  const [taskExecutionMode, setTaskExecutionMode] = useState<TaskExecutionMode>('auto');
  const [researchMode, setResearchMode] = useState<ResearchMode>('standard');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    getBowcomp()
      .getTaskBehaviorSettings()
      .then((settings) => {
        if (cancelled) return;
        setTaskExecutionMode(settings.taskExecutionMode);
        setResearchMode(settings.researchMode);
      })
      .catch((err: unknown) => {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : String(err));
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const save = async (next: {
    taskExecutionMode?: TaskExecutionMode;
    researchMode?: ResearchMode;
  }) => {
    const updated = {
      taskExecutionMode: next.taskExecutionMode ?? taskExecutionMode,
      researchMode: next.researchMode ?? researchMode,
    };
    setSaving(true);
    setError(null);
    try {
      await getBowcomp().setTaskBehaviorSettings(updated);
      setTaskExecutionMode(updated.taskExecutionMode);
      setResearchMode(updated.researchMode);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="rounded-md border border-border bg-background p-3">
      <div className="mb-3">
        <h4 className="text-sm font-medium text-foreground">{t('taskBehavior.title')}</h4>
        <p className="mt-1 text-xs text-muted-foreground">{t('taskBehavior.description')}</p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="space-y-1.5">
          <span className="text-xs font-medium text-muted-foreground">
            {t('taskBehavior.executionLabel')}
          </span>
          <select
            value={taskExecutionMode}
            disabled={saving}
            onChange={(event) =>
              void save({ taskExecutionMode: event.target.value as TaskExecutionMode })
            }
            className="w-full rounded-md border border-input bg-background px-2 py-1.5 text-sm"
          >
            {TASK_EXECUTION_MODES.map((mode) => (
              <option key={mode.value} value={mode.value}>
                {t(mode.labelKey)}
              </option>
            ))}
          </select>
        </label>

        <label className="space-y-1.5">
          <span className="text-xs font-medium text-muted-foreground">
            {t('taskBehavior.researchLabel')}
          </span>
          <select
            value={researchMode}
            disabled={saving}
            onChange={(event) => void save({ researchMode: event.target.value as ResearchMode })}
            className="w-full rounded-md border border-input bg-background px-2 py-1.5 text-sm"
          >
            {RESEARCH_MODES.map((mode) => (
              <option key={mode.value} value={mode.value}>
                {t(mode.labelKey)}
              </option>
            ))}
          </select>
        </label>
      </div>

      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
    </section>
  );
}

export function GeneralTab({
  notificationsEnabled,
  onNotificationsToggle,
  debugMode,
  onDebugToggle,
}: GeneralTabProps) {
  const { t } = useTranslation('settings');

  return (
    <div className="space-y-4">
      <ThemeSelector />
      <LanguageSelector />
      <TaskBehaviorSection />

      <section>
        <NotificationsSection enabled={notificationsEnabled} onToggle={onNotificationsToggle} />
      </section>

      <section>
        <DaemonSection />
      </section>

      <section>
        <h4 className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-3">
          {t('developer.title')}
        </h4>
        <DebugSection debugMode={debugMode} onDebugToggle={onDebugToggle} />
      </section>
    </div>
  );
}
