import { useState, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Input } from '@/components/ui/input';
import { Microphone, CheckCircle, WarningCircle, SpinnerGap } from '@phosphor-icons/react';
import { getBowcomp } from '../../lib/bowcomp';
import { getModifierKeyLabel } from '../../lib/platform';
import { cn } from '@/lib/utils';
import {
  getStoredSpeechProvider,
  isBrowserSpeechRecognitionAvailable,
  isCloudSpeechProvider,
  isSpeechInputProvider,
  setStoredSpeechProvider,
  type CloudSpeechProvider,
  type SpeechInputProvider,
} from '@/hooks/speech-provider';

const modifierKey = getModifierKeyLabel();

interface SpeechSettingsFormProps {
  onSave?: () => void;
  onChange?: (config: { apiKey: string; enabled: boolean }) => void;
}

interface CloudProviderConfig {
  enabled: boolean;
  hasApiKey: boolean;
  apiKeyPrefix?: string;
}

const CLOUD_PROVIDER_LABELS: Record<CloudSpeechProvider, string> = {
  groq: 'Groq Whisper',
  elevenlabs: 'ElevenLabs Speech-to-Text',
};

export function SpeechSettingsForm({ onSave, onChange }: SpeechSettingsFormProps) {
  const { t } = useTranslation('settings');
  const bowcomp = getBowcomp();

  const [provider, setProvider] = useState<SpeechInputProvider>(getStoredSpeechProvider);
  const [apiKey, setApiKey] = useState('');
  const [providerConfigs, setProviderConfigs] = useState<Record<string, CloudProviderConfig>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [saveResult, setSaveResult] = useState<{ success: boolean; message: string } | null>(null);

  const browserAvailable = isBrowserSpeechRecognitionAvailable();
  const selectedCloudConfig = isCloudSpeechProvider(provider)
    ? providerConfigs[provider]
    : undefined;
  const isConfigured =
    provider === 'local'
      ? true
      : provider === 'browser'
        ? browserAvailable
        : Boolean(selectedCloudConfig?.hasApiKey);

  const providerOptions = useMemo(
    () => [
      {
        id: 'local' as const,
        label: t('speech.providerLocal'),
        description: t('speech.providerLocalDescription'),
        available: true,
      },
      {
        id: 'browser' as const,
        label: t('speech.providerBrowser'),
        description: t('speech.providerBrowserDescription'),
        available: browserAvailable,
      },
      {
        id: 'groq' as const,
        label: t('speech.providerGroq'),
        description: t('speech.providerGroqDescription'),
        available: true,
      },
      {
        id: 'elevenlabs' as const,
        label: t('speech.providerElevenLabs'),
        description: t('speech.providerElevenLabsDescription'),
        available: true,
      },
    ],
    [browserAvailable, t],
  );

  const refreshConfig = async () => {
    const config = await bowcomp.speechGetConfig();
    setProviderConfigs(config.providers ?? {});
  };

  useEffect(() => {
    refreshConfig().catch(() => {});
    if (provider === 'browser' && !browserAvailable) {
      setProvider('local');
      setStoredSpeechProvider('local');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bowcomp, browserAvailable, provider]);

  const emitSpeechConfigUpdated = (nextProvider: SpeechInputProvider) => {
    const configured =
      nextProvider === 'local'
        ? true
        : nextProvider === 'browser'
          ? isBrowserSpeechRecognitionAvailable()
          : Boolean(providerConfigs[nextProvider]?.hasApiKey);
    window.dispatchEvent(
      new CustomEvent('speech-config-updated', {
        detail: { isConfigured: configured, provider: nextProvider },
      }),
    );
  };

  const handleProviderChange = (nextProvider: SpeechInputProvider) => {
    setProvider(nextProvider);
    setStoredSpeechProvider(nextProvider);
    setApiKey('');
    setSaveResult(null);
    emitSpeechConfigUpdated(nextProvider);
  };

  const handleSaveApiKey = async () => {
    if (!isCloudSpeechProvider(provider)) {
      handleProviderChange(provider);
      setSaveResult({ success: true, message: t('speech.apiKeySaved') });
      onSave?.();
      return;
    }

    if (!apiKey.trim()) {
      setSaveResult({ success: false, message: t('speech.apiKeyRequired') });
      return;
    }

    setIsLoading(true);
    setSaveResult(null);

    try {
      await bowcomp.addApiKey(provider, apiKey, CLOUD_PROVIDER_LABELS[provider]);
      await refreshConfig();
      setStoredSpeechProvider(provider);
      setSaveResult({ success: true, message: t('speech.apiKeySaved') });
      setApiKey('');
      window.dispatchEvent(
        new CustomEvent('speech-config-updated', {
          detail: { isConfigured: true, provider },
        }),
      );
      onChange?.({ apiKey, enabled: true });
      onSave?.();
    } catch (error) {
      const message = error instanceof Error ? error.message : t('speech.apiKeySaveFailed');
      setSaveResult({ success: false, message });
    } finally {
      setIsLoading(false);
    }
  };

  const selectedHelpLink =
    provider === 'groq'
      ? {
          href: 'https://console.groq.com/keys',
          label: t('speech.groqLink'),
        }
      : provider === 'elevenlabs'
        ? {
            href: 'https://elevenlabs.io/app/settings/api-keys',
            label: t('speech.elevenlabsLink'),
          }
        : null;

  const statusMessage =
    provider === 'local'
      ? t('speech.localAvailable')
      : provider === 'browser'
        ? browserAvailable
          ? t('speech.browserAvailable')
          : t('speech.browserUnavailable')
        : selectedCloudConfig?.hasApiKey
          ? t('speech.apiKeyConfigured')
          : `${t('speech.setupInstructions')} `;

  return (
    <div className="rounded-md border border-border bg-card p-4">
      <div className="mb-3">
        <span className="flex items-center gap-2 text-sm font-semibold text-foreground">
          <Microphone className="h-4 w-4 text-foreground" />
          {t('speech.title')}
        </span>
        <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
          {t('speech.description')}
        </p>
      </div>

      <div className="space-y-2">
        <label className="text-xs font-medium text-muted-foreground">
          {t('speech.providerLabel')}
        </label>
        <div className="grid gap-2 md:grid-cols-4">
          {providerOptions.map((option) => (
            <button
              key={option.id}
              type="button"
              onClick={() => {
                if (option.available && isSpeechInputProvider(option.id)) {
                  handleProviderChange(option.id);
                }
              }}
              disabled={!option.available}
              className={cn(
                'flex min-h-[86px] flex-col rounded-md border px-3 py-2 text-left transition-colors',
                provider === option.id
                  ? 'border-foreground bg-foreground text-background'
                  : 'border-border bg-background text-foreground hover:bg-accent',
                !option.available && 'cursor-not-allowed opacity-60',
              )}
            >
              <span className="text-xs font-semibold">{option.label}</span>
              <span
                className={cn(
                  'mt-1 text-[11px] leading-snug',
                  provider === option.id ? 'text-background/75' : 'text-muted-foreground',
                )}
              >
                {option.description}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-3 rounded-md border border-border bg-background px-3 py-2 text-xs text-foreground">
        <div className="flex items-start gap-2">
          {isConfigured ? (
            <CheckCircle className="mt-0.5 h-4 w-4 shrink-0" />
          ) : (
            <WarningCircle className="mt-0.5 h-4 w-4 shrink-0" />
          )}
          <span>
            {statusMessage}
            {selectedHelpLink &&
              isCloudSpeechProvider(provider) &&
              !selectedCloudConfig?.hasApiKey && (
                <a
                  href={selectedHelpLink.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-medium underline-offset-2 hover:underline"
                >
                  {selectedHelpLink.label}
                </a>
              )}
          </span>
        </div>
      </div>

      {isCloudSpeechProvider(provider) && (
        <div className="mt-3 space-y-2">
          <label className="text-xs font-medium text-foreground">{t('speech.apiKeyLabel')}</label>
          <div className="flex gap-2">
            <Input
              type="password"
              placeholder={
                selectedCloudConfig?.hasApiKey
                  ? (selectedCloudConfig.apiKeyPrefix ?? t('speech.apiKeyMasked'))
                  : t('speech.apiKeyPlaceholder')
              }
              value={apiKey}
              onChange={(e) => {
                setApiKey(e.target.value);
                setSaveResult(null);
              }}
              disabled={isLoading}
              className="h-8 px-2 text-xs"
            />
            <button
              onClick={handleSaveApiKey}
              disabled={isLoading || !apiKey.trim()}
              className="inline-flex h-8 shrink-0 items-center justify-center whitespace-nowrap rounded-md bg-primary px-3 text-xs font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:pointer-events-none disabled:opacity-50"
            >
              {isLoading ? (
                <SpinnerGap className="h-3.5 w-3.5 animate-spin" />
              ) : (
                t('apiKey.saveButton')
              )}
            </button>
          </div>
          <p className="text-[11px] text-muted-foreground">{t('speech.secureStorage')}</p>
        </div>
      )}

      {saveResult && (
        <div
          className={cn(
            'mt-3 flex items-center gap-2 rounded-md border px-2 py-1.5 text-xs',
            saveResult.success
              ? 'border-border bg-background text-foreground'
              : 'border-border bg-background text-destructive',
          )}
        >
          {saveResult.success ? (
            <CheckCircle className="h-3.5 w-3.5" />
          ) : (
            <WarningCircle className="h-3.5 w-3.5" />
          )}
          {saveResult.message}
        </div>
      )}

      <div className="mt-3 rounded-md border border-border bg-background p-3 text-xs">
        <p className="mb-1.5 font-medium text-foreground">{t('speech.howToUse')}</p>
        <ul className="space-y-1 text-[11px] text-muted-foreground">
          <li>
            <strong>{t('speech.clickMicButton')}</strong>
          </li>
          <li>
            <strong>{t('speech.holdAltKey', { modifierKey })}</strong>
          </li>
          <li>
            <strong>{t('speech.voiceConversationShortcut')}</strong>
          </li>
        </ul>
      </div>
    </div>
  );
}
