import { useState, useEffect, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Warning } from '@phosphor-icons/react';
import { useBowcomp } from '@/lib/bowcomp';
import { useDaemonStore } from '@/stores/daemonStore';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

function formatUptime(ms: number): string {
  if (ms <= 0) {
    return '--';
  }
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) {
    return `${days}d ${hours % 24}h`;
  }
  if (hours > 0) {
    return `${hours}h ${minutes % 60}m`;
  }
  if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  }
  return `${seconds}s`;
}

function getDisplayStatus(
  storeStatus: ReturnType<typeof useDaemonStore.getState>['status'],
): string {
  switch (storeStatus) {
    case 'connected':
      return 'running';
    case 'starting':
      return 'starting';
    case 'stopping':
      return 'stopping';
    case 'stopped':
      return 'stopped';
    case 'disconnected':
    case 'reconnecting':
      return 'reconnecting';
    case 'reconnect-failed':
      return 'failed';
    default:
      return 'unknown';
  }
}

function getStatusDotClass(displayStatus: string): string {
  switch (displayStatus) {
    case 'running':
      return 'bg-green-500';
    case 'starting':
      return 'animate-pulse bg-green-500';
    case 'stopping':
      return 'animate-pulse bg-red-500';
    case 'reconnecting':
      return 'animate-pulse bg-yellow-500';
    case 'failed':
    case 'stopped':
      return 'bg-red-500';
    default:
      return 'bg-gray-500';
  }
}

const TRANSITIONAL_STATES = new Set(['starting', 'stopping', 'reconnecting']);

export function DaemonSection() {
  const bowcomp = useBowcomp();
  const { t } = useTranslation('settings');

  const storeStatus = useDaemonStore((s) => s.status);
  const setGlobalStatus = useDaemonStore((s) => s.setStatus);
  const displayStatus = getDisplayStatus(storeStatus);

  const [uptime, setUptime] = useState(0);
  const [lastPing, setLastPing] = useState<Date | null>(null);
  const [actionInProgress, setActionInProgress] = useState<string | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const pollStatus = useCallback(async () => {
    try {
      const result = await bowcomp.daemonPing();
      if (result.status === 'ok') {
        setUptime(result.uptime);
        const currentStatus = useDaemonStore.getState().status;
        if (!TRANSITIONAL_STATES.has(currentStatus)) {
          setGlobalStatus('connected');
        }
      } else {
        setUptime(0);
        const currentStatus = useDaemonStore.getState().status;
        if (!TRANSITIONAL_STATES.has(currentStatus)) {
          setGlobalStatus('stopped');
        }
      }
      setLastPing(new Date());
    } catch {
      setUptime(0);
    }
  }, [bowcomp, setGlobalStatus]);

  useEffect(() => {
    void pollStatus();
    pollRef.current = setInterval(() => void pollStatus(), 10_000);
    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current);
      }
    };
  }, [pollStatus]);

  const handleRestart = async () => {
    setActionInProgress('restart');
    setGlobalStatus('reconnecting');
    try {
      await bowcomp.daemonRestart();
      setGlobalStatus('connected');
      await pollStatus();
    } catch {
      setGlobalStatus('reconnect-failed');
    } finally {
      setActionInProgress(null);
    }
  };

  const handleStop = async () => {
    setActionInProgress('stop');
    setGlobalStatus('stopping');
    try {
      await bowcomp.daemonStop();
      setGlobalStatus('stopped');
      setUptime(0);
    } catch {
      setGlobalStatus('reconnect-failed');
    } finally {
      setActionInProgress(null);
    }
  };

  const handleStart = async () => {
    setActionInProgress('start');
    setGlobalStatus('starting');
    try {
      await bowcomp.daemonStart();
      setGlobalStatus('connected');
      await pollStatus();
    } catch {
      setGlobalStatus('reconnect-failed');
    } finally {
      setActionInProgress(null);
    }
  };

  const dotClass = getStatusDotClass(displayStatus);
  const statusLabel = t(`daemon.status.${displayStatus}`, displayStatus);
  const isRunning = displayStatus === 'running';
  const isFailed = displayStatus === 'failed';

  return (
    <>
      <h4 className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
        {t('daemon.title')}
      </h4>

      <div className="overflow-hidden rounded-md border border-border bg-card">
        <div className="flex items-center justify-between gap-4 px-4 py-3">
          <div className="flex min-w-0 items-center gap-3">
            <span className={cn('h-2.5 w-2.5 shrink-0 rounded-full', dotClass)} />
            <div className="min-w-0">
              <div className="text-sm font-medium text-foreground">{statusLabel}</div>
              <p className="mt-0.5 truncate text-xs text-muted-foreground">
                {isRunning
                  ? t('daemon.status.uptime', { uptime: formatUptime(uptime) })
                  : t('daemon.status.lastPing', {
                      seconds: lastPing
                        ? Math.round((Date.now() - lastPing.getTime()) / 1000)
                        : 0,
                    })}
              </p>
            </div>
          </div>

          <div className="flex shrink-0 overflow-hidden rounded-md border border-border bg-background">
            {isRunning ? (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleRestart}
                  disabled={actionInProgress !== null}
                  className="rounded-none border-r border-border px-3"
                >
                  {actionInProgress === 'restart'
                    ? t('daemon.controls.restarting')
                    : t('daemon.controls.restart')}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleStop}
                  disabled={actionInProgress !== null}
                  className="rounded-none px-3 text-destructive hover:text-destructive"
                >
                  {actionInProgress === 'stop'
                    ? t('daemon.controls.stopping')
                    : t('daemon.controls.stop')}
                </Button>
              </>
            ) : (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleStart}
                disabled={actionInProgress !== null}
                className="rounded-none px-4"
              >
                {actionInProgress === 'start'
                  ? t('daemon.controls.starting')
                  : t('daemon.controls.start')}
              </Button>
            )}
          </div>
        </div>
      </div>

      {isFailed && (
        <div className="mt-3 flex items-start gap-3 rounded-md border border-destructive/30 bg-destructive/10 p-3">
          <Warning className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
          <p className="text-sm text-destructive">{t('daemon.status.failedMessage')}</p>
        </div>
      )}
    </>
  );
}
