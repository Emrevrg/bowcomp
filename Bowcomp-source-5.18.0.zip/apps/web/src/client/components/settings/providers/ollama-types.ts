import type { ToolSupportStatus } from '@bowcomp/agent-core';

export interface OllamaModel {
  id: string;
  name: string;
  toolSupport?: ToolSupportStatus;
}
