import { useState, useCallback, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Globe, CaretDown } from '@phosphor-icons/react';
import { changeLanguage, getLanguagePreference } from '@/i18n';
import { getBowcomp } from '@/lib/bowcomp';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

const AUTO_LABELS: Record<string, string> = {
  en: 'Auto (System)',
  'zh-CN': 'Auto (System)',
  ru: 'Auto (System)',
  fr: 'Auto (System)',
  tr: 'Otomatik (Sistem)',
  es: 'Auto (Sistema)',
  de: 'Auto (System)',
  it: 'Auto (Sistema)',
  'pt-BR': 'Auto (Sistema)',
  ja: 'Auto (System)',
  ko: 'Auto (System)',
  ar: 'Auto (System)',
  hi: 'Auto (System)',
  id: 'Auto (Sistem)',
};
const AUTO_FALLBACK = 'Auto (System)';

const systemLang = typeof navigator !== 'undefined' ? navigator.language : 'en';
const matchedLang = Object.keys(AUTO_LABELS).find(
  (key) =>
    systemLang === key ||
    systemLang.toLowerCase() === key.toLowerCase() ||
    systemLang.toLowerCase().startsWith(`${key.split('-')[0].toLowerCase()}-`),
);
const autoLabel = AUTO_LABELS[matchedLang ?? ''] || AUTO_FALLBACK;

const LANGUAGE_OPTIONS = [
  { value: 'auto' as const, label: autoLabel },
  { value: 'en' as const, label: 'English' },
  { value: 'tr' as const, label: 'Türkçe' },
  { value: 'fr' as const, label: 'Français' },
  { value: 'zh-CN' as const, label: 'Simplified Chinese' },
  { value: 'ru' as const, label: 'Russian' },
];

type LanguageValue = (typeof LANGUAGE_OPTIONS)[number]['value'];
const LANGUAGE_VALUES = new Set<LanguageValue>(LANGUAGE_OPTIONS.map((option) => option.value));

function isLanguageValue(value: string): value is LanguageValue {
  return LANGUAGE_VALUES.has(value as LanguageValue);
}

export function LanguageSelector() {
  const { t } = useTranslation('settings');
  const [currentLanguage, setCurrentLanguage] = useState<LanguageValue>(getLanguagePreference);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const bowcomp = getBowcomp();
    bowcomp
      .getLanguage()
      .then((language) => {
        if (isLanguageValue(language)) {
          setCurrentLanguage(language);
          void changeLanguage(language, { syncMain: false });
        }
      })
      .catch(() => {
        // Keep the local preference already loaded during initial render.
      });

    const unsubscribe = bowcomp.onLanguageChange?.(({ language }) => {
      if (isLanguageValue(language)) {
        setCurrentLanguage(language);
      }
    });

    return () => {
      unsubscribe?.();
    };
  }, []);

  const handleChange = useCallback(async (value: string) => {
    if (!isLanguageValue(value)) {
      return;
    }
    setCurrentLanguage(value);
    await changeLanguage(value);
  }, []);

  const currentLabel = LANGUAGE_OPTIONS.find((opt) => opt.value === currentLanguage)?.label;

  return (
    <div className="rounded-md border border-border bg-card p-4">
      <div className="flex items-center justify-between gap-4">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 font-medium text-foreground">
            <Globe className="h-4 w-4 text-muted-foreground" />
            {t('language.title')}
          </div>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
            {t('language.description')}
          </p>
        </div>
        <DropdownMenu open={open} onOpenChange={setOpen}>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              className={cn(
                'flex h-8 min-w-40 items-center justify-between gap-2 rounded-md border border-border bg-background px-3 text-sm text-foreground transition-colors',
                'hover:bg-accent focus:outline-none focus:ring-2 focus:ring-ring',
              )}
            >
              <span className="truncate">{currentLabel}</span>
              <CaretDown
                className={cn(
                  'h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform',
                  open && 'rotate-180',
                )}
              />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" sideOffset={8} className="max-h-72 w-56 overflow-y-auto">
            <DropdownMenuRadioGroup value={currentLanguage} onValueChange={handleChange}>
              {LANGUAGE_OPTIONS.map((opt) => (
                <DropdownMenuRadioItem key={opt.value} value={opt.value}>
                  {opt.label}
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}
