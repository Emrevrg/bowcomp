import { useState, useCallback, useEffect } from 'react';
import type { McpConnector } from '@bowcomp/agent-core/common';
import type { ConnectorAuthStatus, OAuthProviderId } from '@bowcomp/agent-core/common';
import { getBowcomp } from '@/lib/bowcomp';
import { createLogger } from '@/lib/logger';

const logger = createLogger('useConnectors');

export interface SlackMcpAuthState {
  connected: boolean;
  pendingAuthorization: boolean;
}

export function useConnectors() {
  const [connectors, setConnectors] = useState<McpConnector[]>([]);
  const [slackAuth, setSlackAuth] = useState<SlackMcpAuthState>({
    connected: false,
    pendingAuthorization: false,
  });
  const [builtInAuthStates, setBuiltInAuthStates] = useState<Record<string, ConnectorAuthStatus>>(
    {},
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchConnectors = useCallback(async () => {
    const bowcomp = getBowcomp();
    try {
      const [connectorsResult, slackStatusResult, builtInStatusResult] = await Promise.allSettled([
        bowcomp.getConnectors(),
        bowcomp.getSlackMcpOauthStatus(),
        bowcomp.getBuiltInConnectorAuthStatus(),
      ]);

      if (connectorsResult.status === 'fulfilled') {
        setConnectors(connectorsResult.value);
      }

      if (slackStatusResult.status === 'fulfilled') {
        setSlackAuth(slackStatusResult.value);
      }

      if (builtInStatusResult.status === 'fulfilled') {
        const statusMap: Record<string, ConnectorAuthStatus> = {};
        for (const status of builtInStatusResult.value) {
          statusMap[status.providerId] = status;
        }
        setBuiltInAuthStates(statusMap);
      }

      if (
        connectorsResult.status === 'rejected' &&
        slackStatusResult.status === 'rejected' &&
        builtInStatusResult.status === 'rejected'
      ) {
        throw connectorsResult.reason;
      }

      setError(null);
    } catch (err) {
      logger.error('Failed to load connectors:', err);
      setError(err instanceof Error ? err.message : 'Failed to load connectors');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchConnectors();
  }, [fetchConnectors]);

  const addConnector = useCallback(async (name: string, url: string) => {
    const bowcomp = getBowcomp();
    const connector = await bowcomp.addConnector(name, url);
    setConnectors((prev) => [connector, ...prev]);
    return connector;
  }, []);

  const deleteConnector = useCallback(async (id: string) => {
    const bowcomp = getBowcomp();
    await bowcomp.deleteConnector(id);
    setConnectors((prev) => prev.filter((c) => c.id !== id));
  }, []);

  const toggleEnabled = useCallback(
    async (id: string) => {
      const connector = connectors.find((c) => c.id === id);
      if (!connector) {
        return;
      }

      const bowcomp = getBowcomp();
      await bowcomp.setConnectorEnabled(id, !connector.isEnabled);
      setConnectors((prev) =>
        prev.map((c) => (c.id === id ? { ...c, isEnabled: !c.isEnabled } : c)),
      );
    },
    [connectors],
  );

  const startOAuth = useCallback(async (connectorId: string) => {
    setConnectors((prev) =>
      prev.map((c) => (c.id === connectorId ? { ...c, status: 'connecting' as const } : c)),
    );

    try {
      const bowcomp = getBowcomp();
      return await bowcomp.startConnectorOAuth(connectorId);
    } catch (err) {
      setConnectors((prev) =>
        prev.map((c) => (c.id === connectorId ? { ...c, status: 'error' as const } : c)),
      );
      throw err;
    }
  }, []);

  const completeOAuth = useCallback(async (state: string, code: string) => {
    const bowcomp = getBowcomp();
    const updated = await bowcomp.completeConnectorOAuth(state, code);
    if (updated) {
      setConnectors((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    }
    return updated;
  }, []);

  const disconnect = useCallback(async (connectorId: string) => {
    const bowcomp = getBowcomp();
    await bowcomp.disconnectConnector(connectorId);
    setConnectors((prev) =>
      prev.map((c) => (c.id === connectorId ? { ...c, status: 'disconnected' as const } : c)),
    );
  }, []);

  // Built-in connector actions
  const authenticateBuiltIn = useCallback(
    async (providerId: OAuthProviderId) => {
      setBuiltInAuthStates((prev) => ({
        ...prev,
        [providerId]: {
          ...(prev[providerId] ?? { providerId, connected: false, pendingAuthorization: false }),
          pendingAuthorization: true,
        },
      }));

      try {
        const bowcomp = getBowcomp();
        await bowcomp.loginBuiltInConnector(providerId);
        await fetchConnectors();
      } catch (err) {
        setBuiltInAuthStates((prev) => ({
          ...prev,
          [providerId]: {
            ...(prev[providerId] ?? { providerId, connected: false, pendingAuthorization: false }),
            pendingAuthorization: false,
          },
        }));
        throw err;
      }
    },
    [fetchConnectors],
  );

  const disconnectBuiltIn = useCallback(async (providerId: OAuthProviderId) => {
    const bowcomp = getBowcomp();
    await bowcomp.logoutBuiltInConnector(providerId);
    setBuiltInAuthStates((prev) => ({
      ...prev,
      [providerId]: {
        providerId,
        connected: false,
        pendingAuthorization: false,
      },
    }));
  }, []);

  const authenticateSlack = useCallback(async () => {
    const bowcomp = getBowcomp();

    setSlackAuth(() => ({
      connected: false,
      pendingAuthorization: true,
    }));

    try {
      if (slackAuth.pendingAuthorization) {
        await bowcomp.logoutSlackMcp();
      }

      await bowcomp.loginSlackMcp();
      const status = await bowcomp.getSlackMcpOauthStatus();
      setSlackAuth(status);
      return status;
    } catch (err) {
      try {
        const status = await bowcomp.getSlackMcpOauthStatus();
        setSlackAuth(status);
      } catch {
        setSlackAuth({ connected: false, pendingAuthorization: false });
      }
      throw err;
    }
  }, [slackAuth.pendingAuthorization]);

  const disconnectSlack = useCallback(async () => {
    const bowcomp = getBowcomp();
    await bowcomp.logoutSlackMcp();
    setSlackAuth({ connected: false, pendingAuthorization: false });
  }, []);

  return {
    connectors,
    slackAuth,
    builtInAuthStates,
    loading,
    error,
    addConnector,
    deleteConnector,
    toggleEnabled,
    startOAuth,
    completeOAuth,
    disconnect,
    authenticateBuiltIn,
    disconnectBuiltIn,
    authenticateSlack,
    disconnectSlack,
    refetch: fetchConnectors,
  };
}
