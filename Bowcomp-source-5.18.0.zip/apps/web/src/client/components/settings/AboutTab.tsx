import { useTranslation } from 'react-i18next';

interface AboutTabProps {
  appVersion: string;
}

export function AboutTab({ appVersion }: AboutTabProps) {
  const { t } = useTranslation('settings');
  return (
    <div className="space-y-6">
      <div className="rounded-lg border border-border bg-card p-6">
        <div className="space-y-4">
          <div>
            <div className="text-sm text-muted-foreground">{t('about.title')}</div>
            <div className="font-medium">Bowcomp Desktop</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">{t('about.ownerLabel')}</div>
            <div className="font-medium">{t('about.ownerValue')}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">{t('about.githubLabel')}</div>
            <a
              href="https://github.com/Emrevrg"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium underline hover:no-underline"
            >
              github.com/Emrevrg
            </a>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">{t('about.versionLabel')}</div>
            <div className="font-medium">{appVersion || t('about.loading')}</div>
          </div>
        </div>
        <div className="mt-6 pt-4 border-t border-border text-xs text-muted-foreground">
          {t('about.allRightsReserved')}
        </div>
      </div>
    </div>
  );
}
