import {
  DropdownMenuItem,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
} from '@/components/ui/dropdown-menu';
import {
  DEFAULT_PROVIDERS,
  PROVIDER_META,
  getModelDisplayName,
} from '@bowcomp/agent-core/common';
import type { ConnectedProvider, ProviderId, ToolSupportStatus } from '@bowcomp/agent-core/common';

interface ProviderSubMenuProps {
  providerId: ProviderId;
  provider: ConnectedProvider;
  onSelectModel: (providerId: ProviderId, modelId: string) => Promise<void>;
  disabled: boolean;
}

interface MenuModel {
  id: string;
  displayName: string;
  toolSupport: ToolSupportStatus;
}

function isUnsupportedModel(model: MenuModel): boolean {
  return model.toolSupport === 'unsupported';
}

export function ProviderSubMenu({
  providerId,
  provider,
  onSelectModel,
  disabled,
}: ProviderSubMenuProps) {
  const providerName = PROVIDER_META[providerId]?.name ?? providerId;

  // If availableModels is defined (even empty) use it; only fall back to static config when undefined
  const models: MenuModel[] =
    provider.availableModels !== undefined
      ? provider.availableModels.map((m) => ({
          id: m.id,
          displayName: m.name,
          toolSupport: m.toolSupport ?? 'unknown',
        }))
      : (DEFAULT_PROVIDERS.find((p) => p.id === providerId)?.models ?? []).map((m) => ({
          id: m.fullId,
          displayName: getModelDisplayName(m.fullId),
          toolSupport: 'unknown',
        }));

  return (
    <DropdownMenuSub>
      <DropdownMenuSubTrigger
        disabled={disabled}
        className="gap-2 px-3 py-2 text-sm cursor-pointer"
      >
        {providerName}
      </DropdownMenuSubTrigger>
      <DropdownMenuSubContent className="w-[min(24rem,calc(100vw-2rem))] max-h-[min(30rem,calc(100vh-8rem))] overflow-y-auto overscroll-contain">
        {models.length === 0 ? (
          <DropdownMenuItem disabled className="px-3 py-2 text-sm text-muted-foreground">
            No models available
          </DropdownMenuItem>
        ) : (
          models.map((model) => (
            <DropdownMenuItem
              key={model.id}
              disabled={disabled || isUnsupportedModel(model)}
              className="min-w-0 px-3 py-2 text-sm cursor-pointer"
              onSelect={(event) => {
                event.preventDefault();
                if (isUnsupportedModel(model)) {
                  return;
                }
                void onSelectModel(providerId, model.id);
              }}
              title={model.displayName}
            >
              <span className="min-w-0 flex-1 truncate">{model.displayName}</span>
              {isUnsupportedModel(model) && (
                <span className="ml-auto shrink-0 rounded-sm border px-1.5 py-0.5 text-[10px] leading-none text-muted-foreground">
                  Tools off
                </span>
              )}
            </DropdownMenuItem>
          ))
        )}
      </DropdownMenuSubContent>
    </DropdownMenuSub>
  );
}
