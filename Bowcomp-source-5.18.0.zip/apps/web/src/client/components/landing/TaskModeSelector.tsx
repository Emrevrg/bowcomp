import { useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { CaretLeft, CaretRight } from '@phosphor-icons/react';
import type { ResearchMode, TaskExecutionMode } from '@bowcomp/agent-core';
import { cn } from '@/lib/utils';
import { getBowcomp } from '@/lib/bowcomp';

const TASK_MODES: TaskExecutionMode[] = ['auto', 'short', 'balanced', 'long', 'unlimited'];
const WORK_MODE_KEY = 'bowcomp.workMode';

type WorkMode =
  | 'general'
  | 'deep_research'
  | 'multi_research'
  | 'code'
  | 'multi_code'
  | 'deck'
  | 'multi_deck'
  | 'table'
  | 'document';

const WORK_MODES: Array<{
  id: WorkMode;
  taskExecutionMode: TaskExecutionMode;
  researchMode: ResearchMode;
}> = [
  { id: 'general', taskExecutionMode: 'auto', researchMode: 'standard' },
  { id: 'deep_research', taskExecutionMode: 'long', researchMode: 'deep' },
  { id: 'multi_research', taskExecutionMode: 'long', researchMode: 'multi_deep' },
  { id: 'code', taskExecutionMode: 'balanced', researchMode: 'standard' },
  { id: 'multi_code', taskExecutionMode: 'long', researchMode: 'multi_deep' },
  { id: 'deck', taskExecutionMode: 'balanced', researchMode: 'standard' },
  { id: 'multi_deck', taskExecutionMode: 'long', researchMode: 'multi_deep' },
  { id: 'table', taskExecutionMode: 'balanced', researchMode: 'standard' },
  { id: 'document', taskExecutionMode: 'balanced', researchMode: 'standard' },
];

function nextItem<T>(items: readonly T[], current: T, direction: -1 | 1): T {
  const index = Math.max(0, items.indexOf(current));
  return items[(index + direction + items.length) % items.length];
}

export function TaskModeSelector() {
  const { t } = useTranslation('home');
  const [taskExecutionMode, setTaskExecutionMode] = useState<TaskExecutionMode>('auto');
  const [researchMode, setResearchMode] = useState<ResearchMode>('standard');
  const [workMode, setWorkMode] = useState<WorkMode>('general');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let cancelled = false;
    getBowcomp()
      .getTaskBehaviorSettings()
      .then((settings) => {
        if (cancelled) return;
        setTaskExecutionMode(settings.taskExecutionMode);
        setResearchMode(settings.researchMode);
        const storedWorkMode = window.localStorage.getItem(WORK_MODE_KEY) as WorkMode | null;
        if (storedWorkMode && WORK_MODES.some((mode) => mode.id === storedWorkMode)) {
          setWorkMode(storedWorkMode);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setTaskExecutionMode('auto');
          setResearchMode('standard');
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const save = useCallback(
    async (next: { taskExecutionMode?: TaskExecutionMode; researchMode?: ResearchMode }) => {
      const updated = {
        taskExecutionMode: next.taskExecutionMode ?? taskExecutionMode,
        researchMode: next.researchMode ?? researchMode,
      };
      setTaskExecutionMode(updated.taskExecutionMode);
      setResearchMode(updated.researchMode);
      setSaving(true);
      try {
        await getBowcomp().setTaskBehaviorSettings(updated);
      } finally {
        setSaving(false);
      }
    },
    [researchMode, taskExecutionMode],
  );

  const cycleTaskMode = useCallback(
    (direction: -1 | 1) => {
      void save({ taskExecutionMode: nextItem(TASK_MODES, taskExecutionMode, direction) });
    },
    [save, taskExecutionMode],
  );

  const selectWorkMode = useCallback(
    (mode: (typeof WORK_MODES)[number]) => {
      setWorkMode(mode.id);
      window.localStorage.setItem(WORK_MODE_KEY, mode.id);
      void save({
        taskExecutionMode: mode.taskExecutionMode,
        researchMode: mode.researchMode,
      });
    },
    [save],
  );

  const taskModeButtons = useMemo(
    () =>
      TASK_MODES.map((mode) => (
        <button
          key={mode}
          type="button"
          onClick={() => void save({ taskExecutionMode: mode })}
          className={cn(
            'h-6 rounded-full px-2 text-[10px] font-medium transition-colors whitespace-nowrap',
            taskExecutionMode === mode
              ? 'bg-foreground text-background'
              : 'text-muted-foreground hover:bg-muted hover:text-foreground',
          )}
        >
          {t(`taskModes.execution.${mode}`)}
        </button>
      )),
    [save, t, taskExecutionMode],
  );

  return (
    <div className={cn('flex w-full flex-col gap-2', saving && 'opacity-70')}>
      <div className="flex w-full items-center gap-0.5 overflow-x-auto rounded-md border border-border bg-background/70 p-1 shadow-sm">
        <button
          type="button"
          onClick={() => cycleTaskMode(-1)}
          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
          title={t('taskModes.previous')}
        >
          <CaretLeft className="h-3.5 w-3.5" weight="bold" />
        </button>

        <div className="flex items-center gap-0.5">{taskModeButtons}</div>

        <button
          type="button"
          onClick={() => cycleTaskMode(1)}
          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
          title={t('taskModes.next')}
        >
          <CaretRight className="h-3.5 w-3.5" weight="bold" />
        </button>
      </div>

      <div className="grid w-full grid-cols-2 gap-1.5 sm:grid-cols-3 lg:grid-cols-5">
        {WORK_MODES.map((mode) => (
          <button
            key={mode.id}
            type="button"
            onClick={() => selectWorkMode(mode)}
            className={cn(
              'h-8 rounded-md border px-2.5 text-[11px] font-semibold transition-colors whitespace-nowrap',
              workMode === mode.id
                ? 'border-foreground bg-foreground text-background'
                : 'border-border bg-background/70 text-muted-foreground hover:bg-muted hover:text-foreground',
            )}
          >
            {t(`taskModes.work.${mode.id}`)}
          </button>
        ))}
      </div>
    </div>
  );
}
