import type { ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { ArrowUp } from '@phosphor-icons/react';
import type { useSpeechInput } from '@/hooks/useSpeechInput';
import { SpeechInputButton } from '@/components/ui/SpeechInputButton';
import { VoiceConversationButton } from '@/components/ui/VoiceConversationButton';
import { ModelIndicator } from '@/components/ui/ModelIndicator';
import { getBowcomp } from '@/lib/bowcomp';

interface TaskInputToolbarProps {
  toolbarLeft?: ReactNode;
  onOpenModelSettings?: () => void;
  hideModelWhenNoModel?: boolean;
  speechInput: ReturnType<typeof useSpeechInput>;
  onOpenSpeechSettings?: () => void;
  isSubmitDisabled: boolean;
  isLoading: boolean;
  isInputDisabled: boolean;
  slashCommandOpen: boolean;
  onSubmit: () => void;
  isRecording: boolean;
  value: string;
  isOverLimit: boolean;
  attachmentsCount: number;
}

export function TaskInputToolbar({
  toolbarLeft,
  onOpenModelSettings,
  hideModelWhenNoModel = false,
  speechInput,
  onOpenSpeechSettings,
  isSubmitDisabled,
  isLoading,
  isInputDisabled,
  slashCommandOpen,
  onSubmit,
  isRecording,
  value,
  isOverLimit,
  attachmentsCount,
}: TaskInputToolbarProps) {
  const { t } = useTranslation('common');
  const bowcomp = getBowcomp();
  const submitLabel = isLoading ? t('buttons.stop') : t('buttons.submit');
  const isButtonDisabled = isLoading ? false : isSubmitDisabled || isRecording || slashCommandOpen;

  const buttonColorClass = isLoading
    ? 'bg-destructive text-destructive-foreground hover:bg-destructive/90'
    : isSubmitDisabled || isRecording
      ? 'bg-muted text-muted-foreground/60'
      : 'bg-primary text-primary-foreground hover:bg-primary/90';

  const tooltipText = isOverLimit
    ? t('buttons.messageTooLong')
    : !value.trim() && attachmentsCount === 0
      ? t('buttons.enterMessage')
      : submitLabel;
  const buttonTitle = isButtonDisabled ? tooltipText : submitLabel;

  return (
    <div className="flex min-h-[42px] flex-wrap items-center justify-between gap-x-2 gap-y-1 pl-3 pr-2 pb-2">
      <div className="flex min-w-0 flex-1 items-center gap-2 overflow-visible pr-1">
        {toolbarLeft}
      </div>

      <div className="ml-auto flex shrink-0 items-center gap-2">
        {onOpenModelSettings && (
          <ModelIndicator
            isRunning={false}
            onOpenSettings={onOpenModelSettings}
            hideWhenNoModel={hideModelWhenNoModel}
          />
        )}

        <SpeechInputButton
          isRecording={speechInput.isRecording}
          isTranscribing={speechInput.isTranscribing}
          recordingDuration={speechInput.recordingDuration}
          error={speechInput.error}
          isConfigured={speechInput.isConfigured}
          disabled={isInputDisabled}
          onStartRecording={() => speechInput.startRecording()}
          onStopRecording={() => speechInput.stopRecording()}
          onCancel={() => speechInput.cancelRecording()}
          onRetry={() => speechInput.retry()}
          onOpenSettings={onOpenSpeechSettings}
          size="md"
        />

        <VoiceConversationButton
          isActive={speechInput.isVoiceConversation}
          isRecording={speechInput.isRecording}
          isTranscribing={speechInput.isTranscribing}
          recordingDuration={speechInput.recordingDuration}
          isConfigured={speechInput.isConfigured}
          disabled={isInputDisabled}
          shortcutLabel={speechInput.voiceShortcutLabel}
          onStart={() => {
            void speechInput.startVoiceConversation();
          }}
          onStop={() => {
            void speechInput.stopVoiceConversation();
          }}
          onOpenSettings={onOpenSpeechSettings}
          size="md"
        />

        <button
          data-testid="task-input-submit"
          type="button"
          aria-label={submitLabel}
          aria-disabled={isButtonDisabled}
          title={buttonTitle}
          onClick={() => {
            bowcomp.logEvent({
              level: 'info',
              message: 'Task input submit clicked',
              context: {
                promptLength: value.length,
                attachmentsCount,
              },
            });
            onSubmit();
          }}
          disabled={isButtonDisabled}
          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-all duration-200 ease-bowcomp ${buttonColorClass}`}
        >
          {isLoading ? (
            <span className="block h-[10px] w-[10px] rounded-[1.5px] bg-destructive-foreground" />
          ) : (
            <ArrowUp className="h-4 w-4" weight="bold" />
          )}
        </button>
      </div>
    </div>
  );
}
