import { useTranslation } from 'react-i18next';
import { Binoculars, FolderOpen, Monitor, Paperclip, Sparkle, SquaresFour } from '@phosphor-icons/react';
import type { Skill, McpConnector } from '@bowcomp/agent-core/common';
import {
  DropdownMenuContent,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { SkillsSubmenu } from './SkillsSubmenu';
import { ConnectorsSubmenu } from './ConnectorsSubmenu';

const FEATURE_KEYS = [
  { key: 'modes', icon: Sparkle },
  { key: 'deepResearch', icon: Binoculars },
  { key: 'apps', icon: SquaresFour },
  { key: 'livePreview', icon: Monitor },
] as const;

interface PlusMenuItemsProps {
  skills: Skill[];
  connectors: McpConnector[];
  attachmentCount: number;
  maxAttachments: number;
  isRefreshing: boolean;
  onAttachFiles?: () => void;
  onSelectFolder?: () => void;
  onSkillSelect: (command: string) => void;
  onManageSkills: () => void;
  onCreateNewSkill: () => void;
  onRefresh: () => void;
  onToggleConnector: (id: string, enabled: boolean) => void;
  onManageConnectors: () => void;
}

export function PlusMenuItems({
  skills,
  connectors,
  attachmentCount,
  maxAttachments,
  isRefreshing,
  onAttachFiles,
  onSelectFolder,
  onSkillSelect,
  onManageSkills,
  onCreateNewSkill,
  onRefresh,
  onToggleConnector,
  onManageConnectors,
}: PlusMenuItemsProps) {
  const { t } = useTranslation('home');

  return (
    <DropdownMenuContent align="start" className="w-[200px]">
      <DropdownMenuItem
        disabled={!onAttachFiles || attachmentCount >= maxAttachments}
        onSelect={() => {
          onAttachFiles?.();
        }}
      >
        <Paperclip className="h-4 w-4 mr-2 shrink-0" />
        {t('plusMenu.attachFiles')}
        {attachmentCount > 0 && (
          <span
            className="ml-auto pl-4 text-[10px] text-muted-foreground whitespace-nowrap"
            aria-label={`${attachmentCount} of ${maxAttachments} files attached`}
          >
            {attachmentCount}/{maxAttachments}
          </span>
        )}
      </DropdownMenuItem>

      {window.bowcomp?.pickFolder && onSelectFolder && (
        <DropdownMenuItem onSelect={onSelectFolder}>
          <FolderOpen className="h-4 w-4 mr-2 shrink-0" />
          {t('plusMenu.selectFolder')}
        </DropdownMenuItem>
      )}

      <DropdownMenuSeparator />

      <DropdownMenuSub>
        <DropdownMenuSubTrigger>
          <Sparkle className="h-4 w-4 mr-2 shrink-0" />
          {t('plusMenu.features.title')}
        </DropdownMenuSubTrigger>
        <DropdownMenuSubContent className="w-[320px] p-2">
          <div className="space-y-1">
            {FEATURE_KEYS.map(({ key, icon: Icon }) => (
              <div
                key={key}
                className="flex gap-2 rounded-md px-2 py-2 text-left hover:bg-accent"
              >
                <Icon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                <div className="min-w-0">
                  <div className="text-xs font-medium text-foreground">
                    {t(`plusMenu.features.${key}.title`)}
                  </div>
                  <div className="mt-0.5 text-[11px] leading-snug text-muted-foreground">
                    {t(`plusMenu.features.${key}.description`)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </DropdownMenuSubContent>
      </DropdownMenuSub>

      <DropdownMenuSub>
        <DropdownMenuSubTrigger>
          <svg
            className="h-4 w-4 mr-2"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <path d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          {t('plusMenu.useSkills')}
        </DropdownMenuSubTrigger>
        <DropdownMenuSubContent className="w-[280px] p-0">
          <SkillsSubmenu
            skills={skills}
            onSkillSelect={onSkillSelect}
            onManageSkills={onManageSkills}
            onCreateNewSkill={onCreateNewSkill}
            onRefresh={onRefresh}
            isRefreshing={isRefreshing}
          />
        </DropdownMenuSubContent>
      </DropdownMenuSub>

      {connectors.length > 0 && (
        <DropdownMenuSub>
          <DropdownMenuSubTrigger>
            <svg
              className="h-4 w-4 mr-2"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
            </svg>
            {t('plusMenu.connectors')}
          </DropdownMenuSubTrigger>
          <DropdownMenuSubContent className="w-[280px] p-0">
            <ConnectorsSubmenu
              connectors={connectors}
              onToggle={onToggleConnector}
              onManageConnectors={onManageConnectors}
            />
          </DropdownMenuSubContent>
        </DropdownMenuSub>
      )}
    </DropdownMenuContent>
  );
}
