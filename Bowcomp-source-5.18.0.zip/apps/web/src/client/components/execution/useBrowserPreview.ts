/**
 * useBrowserPreview - State management and IPC event hook for BrowserPreview.
 *
 * Encapsulates frame, URL, status, visibility pause, and auto-start behavior.
 */

import { useEffect, useRef, useCallback, useReducer } from 'react';
import type { ViewStatus } from './StatusBadge';
import { useBrowserPreviewIpc } from './useBrowserPreviewIpc';
import { previewReducer, initialPreviewState, isViewStatus } from './browserPreviewState';

interface UseBrowserPreviewOptions {
  taskId: string;
  pageName?: string | null;
  currentTool?: string | null;
}

export interface UseBrowserPreviewResult {
  frameData: string | null;
  currentUrl: string;
  status: ViewStatus;
  error: string | undefined;
  isCollapsed: boolean;
  setIsCollapsed: (value: boolean) => void;
  imgRef: React.RefObject<HTMLImageElement | null>;
}

function isBrowserAutomationTool(tool: string | null | undefined): boolean {
  if (!tool) {
    return false;
  }
  const normalized = tool.toLowerCase();
  if (normalized.includes('dev-browser')) {
    return true;
  }
  const toolSuffix = normalized.includes('_browser_')
    ? normalized.slice(normalized.lastIndexOf('_browser_') + 1)
    : normalized;
  return toolSuffix.startsWith('browser_') && toolSuffix !== 'browser_screencast';
}

export function useBrowserPreview({
  taskId,
  pageName,
  currentTool,
}: UseBrowserPreviewOptions): UseBrowserPreviewResult {
  const imgRef = useRef<HTMLImageElement>(null);
  const isPausedRef = useRef(false);
  const screencastStartedRef = useRef(false);
  const isCollapsedRef = useRef(false);
  const statusRef = useRef<ViewStatus>('idle');
  const browserToolActiveRef = useRef(false);
  const retryTimerRef = useRef<number | null>(null);

  const [state, dispatch] = useReducer(previewReducer, initialPreviewState);

  const clearRetryTimer = useCallback(() => {
    if (retryTimerRef.current !== null) {
      window.clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
  }, []);

  const requestBrowserPreviewStart = useCallback(
    (delayMs = 0) => {
      const api = window.bowcomp;
      const startBrowserPreview = api?.startBrowserPreview;
      if (!startBrowserPreview) {
        return;
      }

      clearRetryTimer();

      const start = () => {
        retryTimerRef.current = null;
        if (!browserToolActiveRef.current || screencastStartedRef.current) {
          return;
        }

        screencastStartedRef.current = true;
        statusRef.current = 'starting';
        dispatch({ type: 'SET_STARTING' });

        startBrowserPreview(taskId).catch(() => {
          screencastStartedRef.current = false;
          statusRef.current = 'idle';
          dispatch({ type: 'IDLE' });
        });
      };

      if (delayMs > 0) {
        retryTimerRef.current = window.setTimeout(start, delayMs);
      } else {
        start();
      }
    },
    [clearRetryTimer, taskId],
  );

  useEffect(() => {
    clearRetryTimer();
    screencastStartedRef.current = false;
    statusRef.current = 'idle';
    dispatch({ type: 'RESET' });
  }, [clearRetryTimer, taskId]);

  useEffect(() => clearRetryTimer, [clearRetryTimer]);

  useEffect(() => {
    isCollapsedRef.current = state.isCollapsed;
  }, [state.isCollapsed]);

  useEffect(() => {
    const handleVisibility = () => {
      isPausedRef.current = document.hidden;
    };
    handleVisibility();
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);

  useEffect(() => {
    browserToolActiveRef.current = isBrowserAutomationTool(currentTool);
    if (!browserToolActiveRef.current || screencastStartedRef.current) {
      return;
    }
    requestBrowserPreviewStart();
  }, [currentTool, requestBrowserPreviewStart]);

  const handleFrame = useCallback(
    (event: { taskId: string; pageName: string; frame: string; timestamp: number }) => {
      if (event.taskId !== taskId) {
        return;
      }
      if (pageName && event.pageName !== pageName) {
        return;
      }
      if (isPausedRef.current || isCollapsedRef.current) {
        return;
      }
      if (statusRef.current === 'streaming') {
        if (imgRef.current) {
          imgRef.current.src = `data:image/jpeg;base64,${event.frame}`;
        }
      } else {
        dispatch({ type: 'SET_FRAME', frame: event.frame });
        if (imgRef.current) {
          imgRef.current.src = `data:image/jpeg;base64,${event.frame}`;
        }
        statusRef.current = 'streaming';
      }
    },
    [taskId, pageName],
  );

  const handleNavigate = useCallback(
    (event: { taskId: string; pageName: string; url: string }) => {
      if (event.taskId !== taskId) {
        return;
      }
      if (pageName && event.pageName !== pageName) {
        return;
      }
      dispatch({ type: 'SET_URL', url: event.url });
    },
    [taskId, pageName],
  );

  const handleStatus = useCallback(
    (event: { taskId: string; pageName: string; status: string; message?: string }) => {
      if (event.taskId !== taskId) {
        return;
      }
      if (pageName && event.pageName !== pageName) {
        return;
      }
      if (event.status === 'stopped') {
        clearRetryTimer();
        screencastStartedRef.current = false;
        statusRef.current = 'idle';
        dispatch({ type: 'IDLE' });
        return;
      }
      if (event.status === 'error') {
        screencastStartedRef.current = false;
        if (browserToolActiveRef.current) {
          requestBrowserPreviewStart(2500);
        }
      }
      if (!isViewStatus(event.status)) {
        return;
      }
      statusRef.current = event.status;
      dispatch({ type: 'SET_STATUS', status: event.status, message: event.message });
    },
    [clearRetryTimer, requestBrowserPreviewStart, taskId, pageName],
  );

  const setIsCollapsed = useCallback((value: boolean) => {
    dispatch({ type: 'SET_COLLAPSED', value });
  }, []);

  useBrowserPreviewIpc({ taskId, handleFrame, handleNavigate, handleStatus });

  return {
    frameData: state.frameData,
    currentUrl: state.currentUrl,
    status: state.status,
    error: state.error,
    isCollapsed: state.isCollapsed,
    setIsCollapsed,
    imgRef,
  };
}
