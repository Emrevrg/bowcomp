import { useState, useEffect, memo } from 'react';
import { motion } from 'framer-motion';
import { springs } from '../../lib/animations';
import type { TaskMessage } from '@bowcomp/agent-core/common';
import { FileText, FolderOpen, Table, Terminal, Wrench } from '@phosphor-icons/react';
import { cn } from '@/lib/utils';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { StreamingText } from '../ui/streaming-text';
import { BrowserScriptCard } from '../BrowserScriptCard';
import { getToolDisplayInfo } from '../../constants/tool-mappings';
import { SpinningIcon } from './SpinningIcon';
import { markdownComponents, proseClasses } from './message-markdown-config';
import { MessageTaskAction } from './MessageTaskAction';
import { MessageCopyButton } from './MessageCopyButton';
import { getBowcomp } from '@/lib/bowcomp';

export interface MessageBubbleProps {
  message: TaskMessage;
  shouldStream?: boolean;
  isLastMessage?: boolean;
  isRunning?: boolean;
  showTaskActionButton?: boolean;
  taskActionLabel?: string;
  taskActionPendingLabel?: string;
  onTaskAction?: () => void;
  isTaskActionRunning?: boolean;
  taskActionError?: string | null;
  isLoading?: boolean;
}

interface GeneratedArtifact {
  artifactType?: 'table' | 'document' | 'code' | 'presentation';
  csvPath?: string;
  htmlPath?: string;
  documentPath?: string;
  previewPath?: string;
  codePath?: string;
  presentationPath?: string;
  rowCount?: number;
  columnCount?: number;
  slideCount?: number;
  format?: string;
  language?: string;
}

function parseGeneratedArtifact(message: TaskMessage): GeneratedArtifact | null {
  const toolName = message.toolName ?? '';
  if (
    !toolName.includes('desktop_create_table_file') &&
    !toolName.includes('desktop_create_document_file') &&
    !toolName.includes('desktop_create_code_file') &&
    !toolName.includes('desktop_create_presentation_file')
  ) {
    return null;
  }

  const content = message.content ?? '';
  const jsonText = content.trim().startsWith('{') ? content.trim() : content.match(/\{[\s\S]*\}/)?.[0];
  if (!jsonText) return null;

  try {
    const parsed = JSON.parse(jsonText) as GeneratedArtifact;
    if (
      parsed.csvPath ||
      parsed.htmlPath ||
      parsed.documentPath ||
      parsed.previewPath ||
      parsed.codePath ||
      parsed.presentationPath
    ) {
      return parsed;
    }
  } catch {
    return null;
  }
  return null;
}

function GeneratedArtifactCard({ artifact }: { artifact: GeneratedArtifact }) {
  const [expanded, setExpanded] = useState(true);
  const primaryPath =
    artifact.csvPath ?? artifact.documentPath ?? artifact.codePath ?? artifact.presentationPath;
  const previewPath = artifact.htmlPath ?? artifact.previewPath ?? artifact.presentationPath;
  const kind =
    artifact.artifactType ??
    (artifact.csvPath
      ? 'table'
      : artifact.codePath
        ? 'code'
        : artifact.presentationPath
          ? 'presentation'
          : 'document');
  const displayTitle =
    kind === 'table'
      ? 'Yerel tablo hazır'
      : kind === 'code'
        ? 'Kod dosyası hazır'
        : kind === 'presentation'
          ? 'Sunum hazır'
          : 'Yerel doküman hazır';
  const displayDetail =
    kind === 'table'
      ? `${artifact.rowCount ?? 0} satır, ${artifact.columnCount ?? 0} sütun`
      : kind === 'presentation'
        ? `${artifact.slideCount ?? 0} slayt`
        : kind === 'code'
          ? artifact.language ?? 'code'
          : artifact.format ?? 'document';
  const PreviewIcon = kind === 'table' ? Table : kind === 'code' ? Terminal : FileText;

  const open = async (filePath: string | undefined) => {
    if (!filePath) return;
    await getBowcomp().openPath(filePath);
  };

  const show = async (filePath: string | undefined) => {
    if (!filePath) return;
    await getBowcomp().showItemInFolder(filePath);
  };

  return (
    <div className="w-full max-w-[92%] rounded-md border border-border bg-card px-4 py-3">
      <div className="flex items-start gap-3">
        <div className="mt-0.5 flex h-8 w-8 items-center justify-center rounded-md bg-muted">
          <PreviewIcon className="h-4 w-4" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold text-foreground">{displayTitle}</div>
          <div className="mt-0.5 truncate text-xs text-muted-foreground">{displayDetail}</div>
          <div className="mt-2 flex flex-wrap gap-2">
            {previewPath && (
              <button
                type="button"
                onClick={() => setExpanded((value) => !value)}
                className="rounded-md border border-border px-2.5 py-1 text-xs font-medium hover:bg-muted"
              >
                {expanded ? 'Gizle' : 'Görüntüle'}
              </button>
            )}
            {previewPath && (
              <button
                type="button"
                onClick={() => void open(previewPath)}
                className="rounded-md border border-border px-2.5 py-1 text-xs font-medium hover:bg-muted"
              >
                Önizleme
              </button>
            )}
            {primaryPath && (
              <button
                type="button"
                onClick={() => void open(primaryPath)}
                className="rounded-md border border-border px-2.5 py-1 text-xs font-medium hover:bg-muted"
              >
                Dosyayı aç
              </button>
            )}
            {(primaryPath || previewPath) && (
              <button
                type="button"
                onClick={() => void show(primaryPath ?? previewPath)}
                className="inline-flex items-center gap-1 rounded-md border border-border px-2.5 py-1 text-xs font-medium hover:bg-muted"
              >
                <FolderOpen className="h-3.5 w-3.5" />
                Klasör
              </button>
            )}
          </div>
          {previewPath && expanded && (
            <div className="mt-3 overflow-hidden rounded-md border border-border bg-background">
              <iframe
                title={displayTitle}
                src={toFileUrl(previewPath)}
                className="h-[420px] w-full bg-white"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function toFileUrl(filePath: string): string {
  const normalized = filePath.replace(/\\/g, '/');
  const segments = normalized.split('/');
  return `file:///${segments
    .map((segment, index) => (index === 0 ? segment : encodeURIComponent(segment)))
    .join('/')}`;
}

export const MessageBubble = memo(
  function MessageBubble({
    message,
    shouldStream = false,
    isLastMessage = false,
    isRunning = false,
    showTaskActionButton = false,
    taskActionLabel,
    taskActionPendingLabel,
    onTaskAction,
    isTaskActionRunning = false,
    taskActionError,
    isLoading = false,
  }: MessageBubbleProps) {
    const [streamComplete, setStreamComplete] = useState(!shouldStream);
    const isUser = message.type === 'user';
    const isTool = message.type === 'tool';
    const isSystem = message.type === 'system';
    const isAssistant = message.type === 'assistant';

    const toolName = message.toolName || message.content?.match(/Using tool: (\w+)/)?.[1];
    const toolDisplayInfo = toolName ? getToolDisplayInfo(toolName) : undefined;
    const ToolIcon = toolDisplayInfo?.icon;
    const generatedArtifact = isTool ? parseGeneratedArtifact(message) : null;

    useEffect(() => {
      if (!shouldStream) {
        // eslint-disable-next-line react-hooks/set-state-in-effect -- intentional: sync from prop
        setStreamComplete(true);
      }
    }, [shouldStream]);

    if (isTool && message.toolName === 'todowrite') {
      return null;
    }

    if (isTool && message.toolName?.endsWith('complete_task')) {
      return null;
    }

    const showCopyButton = !isTool && !!message.content?.trim();

    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={springs.gentle}
        className={cn('flex flex-col group', isUser ? 'items-end' : 'items-start')}
      >
        {isTool && generatedArtifact ? (
          <GeneratedArtifactCard artifact={generatedArtifact} />
        ) : isTool &&
        toolName?.endsWith('browser_script') &&
        Array.isArray((message.toolInput as { actions?: unknown })?.actions) ? (
          <BrowserScriptCard
            actions={
              (
                message.toolInput as {
                  actions: Array<{
                    action: string;
                    url?: string;
                    selector?: string;
                    ref?: string;
                    text?: string;
                    key?: string;
                  }>;
                }
              ).actions
            }
            isRunning={isLastMessage && isRunning}
          />
        ) : (
          <div
            className={cn(
              'max-w-[85%] rounded-2xl px-4 py-3 transition-all duration-150 relative',
              isUser
                ? 'bg-primary text-primary-foreground'
                : isTool
                  ? 'bg-muted border border-border'
                  : isSystem
                    ? 'bg-muted/50 border border-border'
                    : 'bg-card border border-border',
            )}
          >
            {isTool ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground font-medium">
                {ToolIcon ? <ToolIcon className="h-4 w-4" /> : <Wrench className="h-4 w-4" />}
                <span>{toolDisplayInfo?.label || toolName || 'Processing'}</span>
                {/*
                 * Spinner rule (Phase 1c of the SDK cutover port): prefer
                 * per-message `toolStatus` when it's set by the adapter —
                 * lets non-last tool rows still show running state if they
                 * happen to be in-flight (e.g. two concurrent tool calls).
                 * Fall back to the legacy `isLastMessage && isRunning` prop
                 * for messages without toolStatus (older persisted rows or
                 * non-SDK code paths).
                 */}
                {(message.toolStatus === 'running' ||
                  (message.toolStatus === undefined && isLastMessage && isRunning)) && (
                  <SpinningIcon className="h-3.5 w-3.5 ml-1" />
                )}
              </div>
            ) : (
              <>
                {isSystem && (
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1.5 font-medium">
                    <Terminal className="h-3.5 w-3.5" />
                    System
                  </div>
                )}
                {isUser ? (
                  <p
                    className={cn(
                      'text-sm whitespace-pre-wrap break-words',
                      'text-primary-foreground',
                    )}
                  >
                    {message.content}
                  </p>
                ) : isAssistant && shouldStream && !streamComplete ? (
                  <StreamingText
                    text={message.content}
                    speed={120}
                    isComplete={streamComplete}
                    onComplete={() => setStreamComplete(true)}
                  >
                    {(streamedText) => (
                      <div className={proseClasses}>
                        <ReactMarkdown remarkPlugins={[remarkGfm]} components={markdownComponents}>
                          {streamedText}
                        </ReactMarkdown>
                      </div>
                    )}
                  </StreamingText>
                ) : (
                  <div className={proseClasses}>
                    <ReactMarkdown remarkPlugins={[remarkGfm]} components={markdownComponents}>
                      {message.content}
                    </ReactMarkdown>
                  </div>
                )}
                <p
                  className={cn(
                    'text-xs mt-1.5',
                    isUser ? 'text-primary-foreground/70' : 'text-muted-foreground',
                  )}
                >
                  {new Date(message.timestamp).toLocaleTimeString()}
                </p>
                {isAssistant && showTaskActionButton && onTaskAction && (
                  <MessageTaskAction
                    onTaskAction={onTaskAction}
                    isLoading={isLoading}
                    isTaskActionRunning={isTaskActionRunning}
                    taskActionLabel={taskActionLabel}
                    taskActionPendingLabel={taskActionPendingLabel}
                    taskActionError={taskActionError}
                  />
                )}
              </>
            )}
            {showCopyButton && <MessageCopyButton content={message.content} isUser={isUser} />}
          </div>
        )}
      </motion.div>
    );
  },
  (prev, next) =>
    prev.message.id === next.message.id &&
    prev.shouldStream === next.shouldStream &&
    prev.isLastMessage === next.isLastMessage &&
    prev.isRunning === next.isRunning &&
    prev.showTaskActionButton === next.showTaskActionButton &&
    prev.taskActionLabel === next.taskActionLabel &&
    prev.taskActionPendingLabel === next.taskActionPendingLabel &&
    prev.isTaskActionRunning === next.isTaskActionRunning &&
    prev.taskActionError === next.taskActionError &&
    prev.isLoading === next.isLoading,
);
