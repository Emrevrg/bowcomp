import { cn } from '@/lib/utils';
import { LoaderCircle } from 'lucide-react';

export const SpinningIcon = ({ className }: { className?: string }) => (
  <LoaderCircle aria-hidden="true" className={cn('animate-spin', className)} />
);
