import { memo, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Monitor, ChevronUp, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { springs } from '../../lib/animations';
import { StatusBadge, type ViewStatus } from './StatusBadge';

interface DesktopPreviewProps {
  taskId: string;
  className?: string;
}

function asViewStatus(status: string): ViewStatus | null {
  if (
    status === 'idle' ||
    status === 'starting' ||
    status === 'streaming' ||
    status === 'stopping' ||
    status === 'error'
  ) {
    return status;
  }
  if (status === 'stopped') {
    return 'idle';
  }
  return null;
}

export const DesktopPreview = memo(function DesktopPreview({ taskId, className }: DesktopPreviewProps) {
  const [frame, setFrame] = useState<string | null>(null);
  const [status, setStatus] = useState<ViewStatus>('starting');
  const [message, setMessage] = useState<string | undefined>();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const contentId = `desktop-preview-content-${taskId}`;

  useEffect(() => {
    const api = window.bowcomp;
    const cleanups: Array<() => void> = [];

    cleanups.push(
      api?.onDesktopFrame?.((event) => {
        if (event.taskId === taskId) {
          setFrame(event.frame);
          setStatus('streaming');
        }
      }) ?? (() => {}),
    );
    cleanups.push(
      api?.onDesktopStatus?.((event) => {
        if (event.taskId !== taskId) return;
        const nextStatus = asViewStatus(event.status);
        if (nextStatus) {
          setStatus(nextStatus);
        }
        setMessage(event.message);
      }) ?? (() => {}),
    );

    void api?.startDesktopPreview?.(taskId).catch(() => {
      setStatus('error');
      setMessage('Desktop preview could not start.');
    });

    return () => {
      for (const cleanup of cleanups) {
        cleanup();
      }
      void api?.stopDesktopPreview?.(taskId).catch(() => {});
    };
  }, [taskId]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={springs.gentle}
      className={cn('bg-card border border-border rounded-md overflow-hidden', className)}
    >
      <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-muted/50">
        <Monitor className="h-3.5 w-3.5 text-primary shrink-0" />
        <span className="text-xs text-muted-foreground truncate flex-1 font-mono">
          Desktop Live
        </span>
        <StatusBadge status={status} />
        <button
          type="button"
          onClick={() => setIsCollapsed((value) => !value)}
          className="text-muted-foreground hover:text-foreground transition-colors ml-1"
          aria-label={isCollapsed ? 'Expand' : 'Collapse'}
          aria-expanded={!isCollapsed}
          aria-controls={contentId}
        >
          {isCollapsed ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
        </button>
      </div>

      {!isCollapsed && (
        <div id={contentId} className="relative aspect-video bg-black">
          {frame ? (
            <img
              alt="Desktop preview"
              className="h-full w-full object-contain"
              draggable={false}
              src={frame}
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center text-xs text-white/60">
              {message ?? 'Preparing desktop preview...'}
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
});
