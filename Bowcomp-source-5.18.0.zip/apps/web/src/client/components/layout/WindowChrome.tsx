import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { getBowcomp, getShellPlatform } from '@/lib/bowcomp';
import { cn } from '@/lib/utils';
import iconImage from '/assets/bowcomp-icon.png';

type MenuSection = 'file' | 'edit' | 'view' | 'window' | 'help';

interface MenuItem {
  key: string;
  action: string;
}

const MENU_SECTIONS: Array<{ key: MenuSection; items: MenuItem[] }> = [
  {
    key: 'file',
    items: [
      { key: 'newTask', action: 'file:new-task' },
      { key: 'settings', action: 'file:settings' },
      { key: 'closeWindow', action: 'file:close' },
      { key: 'quit', action: 'file:quit' },
    ],
  },
  {
    key: 'edit',
    items: [
      { key: 'undo', action: 'edit:undo' },
      { key: 'redo', action: 'edit:redo' },
      { key: 'cut', action: 'edit:cut' },
      { key: 'copy', action: 'edit:copy' },
      { key: 'paste', action: 'edit:paste' },
      { key: 'selectAll', action: 'edit:select-all' },
    ],
  },
  {
    key: 'view',
    items: [
      { key: 'reload', action: 'view:reload' },
      { key: 'forceReload', action: 'view:force-reload' },
      { key: 'toggleDevTools', action: 'view:toggle-devtools' },
      { key: 'zoomIn', action: 'view:zoom-in' },
      { key: 'zoomOut', action: 'view:zoom-out' },
      { key: 'resetZoom', action: 'view:reset-zoom' },
      { key: 'toggleFullscreen', action: 'view:toggle-fullscreen' },
    ],
  },
  {
    key: 'window',
    items: [
      { key: 'minimize', action: 'window:minimize' },
      { key: 'maximize', action: 'window:maximize' },
      { key: 'closeWindow', action: 'window:close' },
    ],
  },
  {
    key: 'help',
    items: [{ key: 'about', action: 'help:about' }],
  },
];

export function WindowChrome() {
  const platform = getShellPlatform();
  const { t } = useTranslation('common');
  const [openMenu, setOpenMenu] = useState<MenuSection | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handlePointerDown = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) {
        setOpenMenu(null);
      }
    };
    window.addEventListener('pointerdown', handlePointerDown);
    return () => window.removeEventListener('pointerdown', handlePointerDown);
  }, []);

  const runAction = async (action: string) => {
    setOpenMenu(null);
    await getBowcomp().runWindowMenuAction(action);
  };

  return (
    <div
      className={cn(
        'drag-region flex h-9 shrink-0 items-center border-b border-border bg-background text-foreground',
        platform === 'darwin' ? 'pl-20 pr-3' : 'pl-3 pr-[140px]',
      )}
    >
      <div className="flex min-w-0 items-center gap-2">
        <img src={iconImage} alt="" className="h-4 w-4 object-contain invert dark:invert-0" />
        <span className="truncate text-xs font-medium">Bowcomp</span>
      </div>
      <div
        ref={menuRef}
        className="no-drag relative ml-5 hidden items-center gap-1 text-xs text-muted-foreground sm:flex"
      >
        {MENU_SECTIONS.map((section) => (
          <div key={section.key} className="relative">
            <button
              type="button"
              className={cn(
                'rounded px-2 py-1 transition-colors hover:bg-accent hover:text-foreground',
                openMenu === section.key && 'bg-accent text-foreground',
              )}
              onClick={() => setOpenMenu((current) => (current === section.key ? null : section.key))}
              aria-haspopup="menu"
              aria-expanded={openMenu === section.key}
            >
              {t(`windowMenu.sections.${section.key}`)}
            </button>
            {openMenu === section.key && (
              <div
                role="menu"
                className="absolute left-0 top-[28px] z-50 min-w-[178px] rounded-md border border-border bg-popover py-1 text-popover-foreground shadow-lg"
              >
                {section.items.map((item) => (
                  <button
                    key={item.action}
                    role="menuitem"
                    type="button"
                    className="flex w-full items-center px-3 py-1.5 text-left text-xs hover:bg-accent hover:text-accent-foreground"
                    onClick={() => {
                      void runAction(item.action);
                    }}
                  >
                    {t(`windowMenu.items.${item.key}`)}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
