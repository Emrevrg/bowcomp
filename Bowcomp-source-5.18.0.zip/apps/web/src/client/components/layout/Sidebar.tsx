'use client';

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useTaskStore } from '@/stores/taskStore';
import { getBowcomp } from '@/lib/bowcomp';
import { staggerContainer } from '@/lib/animations';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import ConversationListItem from './ConversationListItem';
import SettingsDialog from './SettingsDialog';
import WorkspaceSelector from './WorkspaceSelector';
import { Gear, ChatText, MagnifyingGlass, CaretLeft, CaretRight } from '@phosphor-icons/react';
import { DaemonStatusDot } from '@/components/DaemonStatusDot';
import { cn } from '@/lib/utils';
import logoImage from '/assets/logo-1.png';
import iconImage from '/assets/bowcomp-icon.png';

const SIDEBAR_COLLAPSED_KEY = 'bowcomp.sidebarCollapsed';

export default function Sidebar() {
  const navigate = useNavigate();
  const [showSettings, setShowSettings] = useState(false);
  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem(SIDEBAR_COLLAPSED_KEY) === 'true';
    } catch {
      return false;
    }
  });
  const [settingsInitialTab, setSettingsInitialTab] = useState<
    | 'providers'
    | 'voice'
    | 'skills'
    | 'integrations'
    | 'workspaces'
    | 'scheduler'
    | 'general'
    | 'about'
  >('providers');
  const { tasks, loadTasks, updateTaskStatus, addTaskUpdate, openLauncher } = useTaskStore();
  const bowcomp = getBowcomp();
  const { t } = useTranslation('sidebar');

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  useEffect(() => {
    try {
      localStorage.setItem(SIDEBAR_COLLAPSED_KEY, String(collapsed));
    } catch {
      // Ignore storage failures in restricted renderer contexts.
    }
  }, [collapsed]);

  // Subscribe to task status changes (queued -> running) and task updates (complete/error)
  // This ensures sidebar always reflects current task status
  useEffect(() => {
    const unsubscribeStatusChange = bowcomp.onTaskStatusChange?.((data) => {
      updateTaskStatus(data.taskId, data.status);
    });

    const unsubscribeTaskUpdate = bowcomp.onTaskUpdate((event) => {
      addTaskUpdate(event);
    });

    return () => {
      unsubscribeStatusChange?.();
      unsubscribeTaskUpdate();
    };
  }, [updateTaskStatus, addTaskUpdate, bowcomp]);

  const handleNewConversation = () => {
    navigate('/');
  };

  return (
    <>
      <div
        className={cn(
          'flex h-full flex-col border-r border-border bg-card transition-[width] duration-200 ease-out',
          collapsed ? 'w-[68px]' : 'w-[236px]',
        )}
      >
        {/* Workspace Selector */}
        <div
          className={cn(
            'flex items-center px-2 pb-2 pt-2',
            collapsed ? 'justify-center' : 'gap-2',
          )}
        >
          {!collapsed && (
            <div className="min-w-0 flex-1">
              <WorkspaceSelector
                onManageWorkspaces={() => {
                  setSettingsInitialTab('workspaces');
                  setShowSettings(true);
                }}
              />
            </div>
          )}
          <Button
            data-testid="sidebar-toggle-button"
            onClick={() => setCollapsed((value) => !value)}
            variant="ghost"
            size="icon-sm"
            className="shrink-0"
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <CaretRight className="h-4 w-4" /> : <CaretLeft className="h-4 w-4" />}
          </Button>
        </div>

        {/* Action Buttons */}
        <div
          className={cn(
            'border-b border-border px-2 py-2',
            collapsed ? 'flex flex-col gap-2' : 'flex gap-2',
          )}
        >
          <Button
            data-testid="sidebar-new-task-button"
            onClick={handleNewConversation}
            variant="default"
            size="sm"
            className={cn('justify-center gap-2', collapsed ? 'w-full px-0' : 'flex-1')}
            title={t('newTask')}
          >
            <ChatText className="h-4 w-4" />
            {!collapsed && t('newTask')}
          </Button>
          <Button
            onClick={openLauncher}
            variant="outline"
            size="sm"
            className={cn(collapsed ? 'w-full px-0' : 'px-2')}
            title={t('searchTasks')}
          >
            <MagnifyingGlass className="h-4 w-4" />
          </Button>
        </div>

        {/* Conversation List */}
        {collapsed ? (
          <div className="flex-1" />
        ) : (
          <ScrollArea className="flex-1">
            <div className="space-y-1 p-2">
              <AnimatePresence mode="wait">
                {tasks.length === 0 ? (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="px-2 py-6 text-center text-sm text-muted-foreground"
                  >
                    {t('noConversations')}
                  </motion.div>
                ) : (
                  <motion.div
                    key="task-list"
                    variants={staggerContainer}
                    initial="initial"
                    animate="animate"
                    className="space-y-1"
                  >
                    {tasks.map((task) => (
                      <ConversationListItem key={task.id} task={task} />
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </ScrollArea>
        )}

        {/* Bottom Section - Logo and Settings */}
        <div
          className={cn(
            'border-t border-border',
            collapsed
              ? 'flex flex-col items-center gap-2 px-2 py-2.5'
              : 'flex items-center justify-between px-3 py-2.5',
          )}
        >
          {/* Logo - Bottom Left */}
          <div className="flex items-center">
            <img
              src={collapsed ? iconImage : logoImage}
              alt="Bowcomp"
              className={cn(
                'object-contain invert dark:invert-0',
                collapsed ? 'h-11 w-11' : 'h-10 w-auto',
              )}
            />
          </div>

          {/* Settings Button + Daemon Status - Bottom Right */}
          <div className={cn('flex items-center gap-2', collapsed && 'flex-col')}>
            <DaemonStatusDot />
            <Button
              data-testid="sidebar-settings-button"
              variant="ghost"
              size="icon"
              onClick={() => {
                setSettingsInitialTab('providers');
                setShowSettings(true);
              }}
              title={t('settings')}
            >
              <Gear className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <SettingsDialog
        open={showSettings}
        onOpenChange={setShowSettings}
        initialTab={settingsInitialTab}
      />
    </>
  );
}
