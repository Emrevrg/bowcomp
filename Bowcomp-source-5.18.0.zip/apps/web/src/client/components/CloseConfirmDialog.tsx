import { useState, useEffect, useCallback } from 'react';
import { Warning, Power, ArrowRight } from '@phosphor-icons/react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useBowcomp } from '@/lib/bowcomp';
import { cn } from '@/lib/utils';

type CloseDecision = 'keep-daemon' | 'stop-daemon';

export function CloseConfirmDialog() {
  const bowcomp = useBowcomp();
  const [open, setOpen] = useState(false);
  const [decision, setDecision] = useState<CloseDecision>('keep-daemon');

  useEffect(() => {
    if (!bowcomp.onCloseRequested) {
      return;
    }
    const unsubscribe = bowcomp.onCloseRequested(() => {
      setDecision('keep-daemon');
      setOpen(true);
    });
    return unsubscribe;
  }, [bowcomp]);

  const handleConfirm = useCallback(() => {
    setOpen(false);
    bowcomp.respondToClose?.(decision);
  }, [bowcomp, decision]);

  const handleCancel = useCallback(() => {
    setOpen(false);
    bowcomp.respondToClose?.('cancel');
  }, [bowcomp]);

  const isKeepDaemon = decision === 'keep-daemon';

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) {
          handleCancel();
        }
      }}
    >
      <DialogContent className="overflow-hidden p-0 sm:max-w-[420px]">
        <div className="border-b border-border px-5 py-4">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <Power className="h-5 w-5" weight="bold" />
              Close Bowcomp
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              Choose what should happen when the window closes.
            </DialogDescription>
          </DialogHeader>
        </div>

        <div className="px-5 py-4">
          <div className="overflow-hidden rounded-md border border-border bg-background">
            <CloseOption
              selected={isKeepDaemon}
              title="Close window"
              description="Keep background tasks and integrations running in the tray."
              onClick={() => setDecision('keep-daemon')}
            />
            <CloseOption
              selected={!isKeepDaemon}
              danger
              title="Close and stop"
              description="Stop background processing until Bowcomp is opened again."
              onClick={() => setDecision('stop-daemon')}
            />
          </div>

          {!isKeepDaemon && (
            <div className="mt-3 flex items-start gap-2 rounded-md border border-destructive/25 bg-destructive/10 p-3">
              <Warning className="mt-0.5 h-4 w-4 shrink-0 text-destructive" weight="bold" />
              <p className="text-xs leading-relaxed text-destructive">
                Scheduled jobs, integrations, and background message processing will stop
                immediately.
              </p>
            </div>
          )}
        </div>

        <DialogFooter className="border-t border-border bg-muted/30 px-5 py-3 sm:justify-between">
          <Button variant="ghost" onClick={handleCancel}>
            Cancel
          </Button>
          <Button
            variant={isKeepDaemon ? 'default' : 'destructive'}
            onClick={handleConfirm}
            className="gap-1.5"
          >
            {isKeepDaemon ? 'Close' : 'Close & Stop'}
            <ArrowRight className="h-3.5 w-3.5" weight="bold" />
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function CloseOption({
  selected,
  danger,
  title,
  description,
  onClick,
}: {
  selected: boolean;
  danger?: boolean;
  title: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex w-full items-start gap-3 border-b border-border px-3.5 py-3 text-left last:border-b-0 transition-colors',
        selected ? 'bg-foreground text-background' : 'bg-background text-foreground hover:bg-muted',
        danger && selected && 'bg-destructive text-destructive-foreground',
      )}
    >
      <span
        className={cn(
          'mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border',
          selected ? 'border-current' : 'border-muted-foreground/50',
        )}
      >
        {selected && <span className="h-2 w-2 rounded-full bg-current" />}
      </span>
      <span className="min-w-0">
        <span className="block text-sm font-medium">{title}</span>
        <span
          className={cn(
            'mt-0.5 block text-xs leading-relaxed',
            selected ? 'text-current/75' : 'text-muted-foreground',
          )}
        >
          {description}
        </span>
      </span>
    </button>
  );
}
